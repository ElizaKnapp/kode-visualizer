# PR Map: install

PR Map turns a PR into a map in Cursor's bottom panel: one tab per flow, the files to read in order, and
what each file's diff changes. Cursor's chat on the right knows which flow, file and lines you're looking
at.

## You need

- **Cursor**
- **Claude Code**, signed in (`claude auth status` says `"loggedIn": true`)
- **Node 20.7 or newer** (`node --version`)
- **GitHub CLI**, signed in (`gh auth status`)

## Install

1. Unzip, and put the `pr-map` folder at `~/.claude/skills/pr-map`:

   ```bash
   mkdir -p ~/.claude/skills && mv pr-map ~/.claude/skills/pr-map
   ```

2. Install the pinned PR Lens, once:

   ```bash
   ~/.claude/skills/pr-map/bin/setup
   ```

3. Install the Cursor extension, then reload Cursor (Cmd+Shift+P → **Developer: Reload Window**):

   ```bash
   cursor --install-extension ~/.claude/skills/pr-map/pr-map-0.1.0.vsix
   ```

## Use it

1. Check out the PR's branch in the repo.
2. Make a map, either way:
   - In Cursor's bottom panel, open the **PR Map** tab and click **Map this PR**.
   - Or run `claude` in the repo and type `/pr-map`.
3. Read it in the **PR Map** tab: pick a flow, then open its files in order. "This file" shows what the PR
   changes in the file you have open.
4. Ask questions in Cursor's chat, like "why does this file allow `pending?`". It knows the flow, the file,
   and your selected lines.

A map takes about 2 to 3 minutes for a typical PR, up to 8 for a big one, and costs about $1 to $2 in
Claude usage.

## What it touches

- **Nothing leaves your machine** except what Claude Code itself sends. PR Lens (the diagram drawer) is
  pinned, and only its offline `validate` and `render` commands run. Nothing is posted to GitHub.
- **Map making is read-only.** Claude can read the repo and run read-only `git` commands. It can write only
  inside `.pr-lens/`.
- **Two local files are added to the repo and kept out of git** through `.git/info/exclude`, never
  `.gitignore`: the `.pr-lens/` folder, and `.cursor/rules/pr-map.mdc`, which points Cursor's chat at the
  map. `git status` doesn't change.

## Remove it

```bash
cursor --uninstall-extension kikoff-local.pr-map
rm -rf ~/.claude/skills/pr-map
```

In each repo you mapped, you can also delete `.pr-lens/` and `.cursor/rules/pr-map.mdc`.
