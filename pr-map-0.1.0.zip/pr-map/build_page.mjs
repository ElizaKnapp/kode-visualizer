#!/usr/bin/env node
// Builds one local HTML page from a PR Lens render plus the pr-map sidecar.
// Usage: node build_page.mjs <drawing-dir> <sidecar.json> --head <sha>
import { readFileSync, writeFileSync, renameSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const ENTITIES = { "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&#39;": "'" };
const decode = (s) => s.replace(/&(amp|lt|gt|quot|#39);/g, (m) => ENTITIES[m]);
export const escapeHtml = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

const attr = (tag, name) => {
  const m = tag.match(new RegExp(`\\b${name}="([^"]*)"`));
  return m ? m[1] : undefined;
};

// PR Lens boxes carry no ids. A box is a <rect class="card…"> with a <text class="ntitle"> inside it,
// so each title is paired with the card whose rectangle contains the title's x,y.
export function findBoxes(svg) {
  const cards = [...svg.matchAll(/<rect class="card[^"]*"[^>]*>/g)].map(([tag]) => ({
    x: +attr(tag, "x"), y: +attr(tag, "y"), width: +attr(tag, "width"), height: +attr(tag, "height"),
  }));
  const titles = [...svg.matchAll(/<text class="ntitle[^"]*"([^>]*)>([^<]*)<\/text>/g)].map(([, attrs, text]) => ({
    x: +attr(attrs, "x"), y: +attr(attrs, "y"), title: decode(text),
  }));
  return titles.flatMap(({ x, y, title }) => {
    const card = cards.find((c) => x >= c.x && x <= c.x + c.width && y >= c.y && y <= c.y + c.height);
    return card ? [{ title, ...card }] : [];
  });
}

// A title that didn't fit is cut short with "…", so a cut title matches any label it starts.
const titleFits = (title, label) =>
  title === label || (title.endsWith("…") && label.startsWith(title.slice(0, -1).trimEnd()));

export function matchBoxes(boxes, nodes) {
  const byNode = {};
  const warnings = [];
  for (const node of nodes) {
    const hits = boxes.filter((b) => titleFits(b.title, node.label));
    if (hits.length === 0) {
      warnings.push(`No box found for "${node.label}", so it has no link.`);
      continue;
    }
    const rivals = nodes.filter((n) => n !== node && hits.some((b) => titleFits(b.title, n.label)));
    if (hits.length > 1 || rivals.length > 0) {
      warnings.push(`"${node.label}" matches more than one box, so it has no link. Give it a shorter, unique label.`);
      continue;
    }
    byNode[node.id] = hits[0];
  }
  return { byNode, warnings };
}

export function cursorLink(root, target) {
  const path = `${root.replace(/\/+$/, "")}/${target.path}`
    .split("/")
    .map(encodeURIComponent)
    .join("/");
  return `cursor://file${path.startsWith("/") ? "" : "/"}${path}:${target.line ?? 1}`;
}

// `broken` means the sidecar and the drawing disagree, so the map can't be shown. `stale` means the map
// is fine but describes an older commit, so it's shown with a warning.
export function checkMap(graph, sidecar, head) {
  const nodeIds = new Set(graph.nodes.map((n) => n.id));
  const stepIds = new Set((graph.walkthrough?.steps ?? []).map((s) => s.id));
  const broken = [];
  const stale = [];
  if (head && sidecar.mapped?.head !== head) {
    stale.push(`This map is for commit ${(sidecar.mapped?.head ?? "unknown").slice(0, 10)}, but the branch is now at ${head.slice(0, 10)}. Redraw to catch up.`);
  }
  for (const id of Object.keys(sidecar.targets ?? {})) {
    if (!nodeIds.has(id)) broken.push(`targets names node "${id}", which isn't in the drawing.`);
  }
  for (const step of sidecar.steps ?? []) {
    if (!nodeIds.has(step.node)) broken.push(`Step ${step.number} names node "${step.node}", which isn't in the drawing.`);
    if (!stepIds.has(step.walkthroughStep)) broken.push(`Step ${step.number} names walkthrough step "${step.walkthroughStep}", which isn't in the drawing.`);
  }
  // Views can nest inside other views, so every level counts.
  const viewIds = new Set();
  const collect = (views) => views.forEach((v) => (viewIds.add(v.id), collect(v.children ?? [])));
  collect(graph.views ?? []);
  for (const flow of sidecar.flows ?? []) {
    if (!viewIds.has(flow.view)) broken.push(`Flow "${flow.id}" names view "${flow.view}", which isn't in the drawing.`);
    for (const file of flow.files ?? []) {
      if (file.node && !nodeIds.has(file.node)) broken.push(`Flow "${flow.id}" names node "${file.node}", which isn't in the drawing.`);
    }
    if (flow.trigger?.node && !nodeIds.has(flow.trigger.node)) broken.push(`Flow "${flow.id}" has trigger node "${flow.trigger.node}", which isn't in the drawing.`);
  }
  return { broken, stale };
}

// The top architecture view. Child views nest inside their parent, so the top level is the list itself.
export function overviewAsset(manifest, graph) {
  const top = (graph.views ?? []).find((v) => v.lens === "architecture");
  return manifest.assets.find((a) => a.view === top?.id) ?? manifest.assets.find((a) => a.lens === "architecture");
}

function overlay({ byNode, sidecar }) {
  // A node can be more than one step of the story, so its badge can read "1, 5".
  const numbers = {};
  for (const s of sidecar.steps ?? []) (numbers[s.node] ??= []).push(s.number);
  const parts = [];
  for (const [id, box] of Object.entries(byNode)) {
    const target = sidecar.targets?.[id];
    const rect = `<rect class="pm-hit" data-node="${escapeHtml(id)}" x="${box.x}" y="${box.y}" width="${box.width}" height="${box.height}" rx="10"/>`;
    if (target?.deleted) {
      parts.push(`<g class="pm-deleted"><title>${escapeHtml(target.path)}: deleted in this PR</title>${rect}</g>`);
    } else if (target) {
      const where = `${target.path}:${target.line ?? 1}`;
      parts.push(`<a href="${escapeHtml(cursorLink(sidecar.root, target))}"><title>Open ${escapeHtml(where)} in Cursor</title>${rect}</a>`);
    }
    if (numbers[id]) {
      const label = numbers[id].sort((a, b) => a - b).join(", ");
      const width = 16 + 7 * label.length;
      parts.push(`<g class="pm-badge" data-node="${escapeHtml(id)}"><rect x="${box.x - 8}" y="${box.y - 10}" width="${width}" height="22" rx="11"/><text x="${box.x - 8 + width / 2}" y="${box.y + 5.5}">${label}</text></g>`);
    }
  }
  return `<g class="pm-overlay">${parts.join("")}</g>`;
}

const FILE_ROWS = 10;

// Newer sidecars list every changed file in `files`. Older ones carry `fileTable` and `folded`.
export function fileSections(sidecar) {
  if (!sidecar.files) return { rows: sidecar.fileTable ?? [], folded: sidecar.folded ?? [] };
  const rows = sidecar.files
    .filter((f) => f.step != null)
    .sort((a, b) => a.step - b.step)
    .map((f) => ({ step: f.step, path: f.path, line: f.line, role: f.does, deleted: f.status === "deleted" }));
  const groups = new Map();
  for (const f of sidecar.files.filter((f) => f.step == null)) {
    const label = f.group ?? "Other";
    if (!groups.has(label)) groups.set(label, []);
    groups.get(label).push(f.path);
  }
  return { rows, folded: [...groups].map(([label, paths]) => ({ label, paths })) };
}

function fileTable(sidecar) {
  const { rows, folded: groups } = fileSections(sidecar);
  const row = (r) => {
    const target = { path: r.path, line: r.line };
    const name = r.deleted
      ? `<span class="pm-gone">${escapeHtml(r.path)}</span> <em>deleted</em>`
      : `<a href="${escapeHtml(cursorLink(sidecar.root, target))}">${escapeHtml(r.path)}</a>`;
    return `<tr><td>${escapeHtml(r.step ?? "")}</td><td>${name}</td><td>${escapeHtml(r.role)}</td></tr>`;
  };
  const shown = rows.slice(0, FILE_ROWS).map(row).join("");
  const rest = rows.slice(FILE_ROWS);
  const more = rest.length
    ? `<details><summary>+${rest.length} more files</summary><table>${rest.map(row).join("")}</table></details>`
    : "";
  const folded = groups
    .map((f) => `<details><summary>${escapeHtml(f.label)} (${f.paths.length})</summary><ul>${f.paths
      .map((p) => `<li><a href="${escapeHtml(cursorLink(sidecar.root, { path: p }))}">${escapeHtml(p)}</a></li>`)
      .join("")}</ul></details>`)
    .join("");
  return `<table class="pm-files"><thead><tr><th>Step</th><th>File</th><th>What it does</th></tr></thead><tbody>${shown}</tbody></table>${more}${folded}`;
}

function stepList(graph, sidecar) {
  const steps = new Map((graph.walkthrough?.steps ?? []).map((s) => [s.id, s]));
  return (sidecar.steps ?? [])
    .slice()
    .sort((a, b) => a.number - b.number)
    .map((s) => {
      const step = steps.get(s.walkthroughStep);
      // A step can point at its own line, for when two steps share one box.
      const nodeTarget = sidecar.targets?.[s.node];
      const target = nodeTarget && { ...nodeTarget, line: s.line ?? nodeTarget.line };
      const title = escapeHtml(step?.heading ?? s.walkthroughStep);
      const head = target && !target.deleted
        ? `<a href="${escapeHtml(cursorLink(sidecar.root, target))}">${title}</a>`
        : title;
      const where = target ? `<code>${escapeHtml(target.path)}${target.deleted ? " (deleted)" : ""}</code>` : "";
      return `<li data-node="${escapeHtml(s.node)}"><span class="pm-n">${s.number}</span><div>${head}<p>${escapeHtml(step?.body ?? "")}</p>${where}</div></li>`;
    })
    .join("");
}

const LEGEND = `
<ul class="pm-legend">
  <li><span class="sw sw-added"></span><span><b>Green box</b>: new in this PR</span></li>
  <li><span class="sw sw-modified"></span><span><b>Amber box</b>: changed in this PR</span></li>
  <li><span class="sw sw-removed"></span><span><b>Faded red dashed box, crossed-out name</b>: deleted in this PR</span></li>
  <li><span class="sw sw-unchanged"></span><span><b>Grey box</b>: untouched code the change talks to</span></li>
  <li><span class="pm-n">3</span><span><b>Number</b>: its step in the story below. Read 1 first.</span></li>
  <li><span><b>Arrow</b>: one part calls or sends to another. Same colors as boxes. A dashed red arrow is a call this PR removes.</span></li>
  <li><span><b>Moving dots</b>: the main path the change adds.</span></li>
  <li><span><b>Click a box, step or file</b> to open it in Cursor at that line.</span></li>
</ul>
<p class="pm-note">Arrows are drawn by an AI reading the diff. They are not checked against the code yet.</p>`;

const STYLE = `
:root { font: 14px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; color: #1f2328; }
body { margin: 0; background: #f6f8fa; }
header { padding: 14px 24px; background: #fff; border-bottom: 1px solid #d1d9e0; }
header h1 { font-size: 18px; margin: 0 0 4px; }
header p { margin: 0; color: #59636e; }
.pm-banner { margin: 12px 24px 0; padding: 10px 14px; background: #fff8c5; border: 1px solid #d4a72c; border-radius: 6px; }
.pm-banner ul { margin: 4px 0 0; padding-left: 18px; }
main { padding: 16px 24px; }
.pm-diagram { background: #fff; border: 1px solid #d1d9e0; border-radius: 8px; overflow-x: auto; margin-bottom: 16px; }
.pm-diagram svg { display: block; width: 100%; min-width: 1100px; height: auto; }
aside { display: grid; grid-template-columns: 300px minmax(0, 1.3fr) minmax(0, 1fr); gap: 16px; align-items: start; }
@media (max-width: 1100px) { aside { grid-template-columns: 1fr; } }
aside section { background: #fff; border: 1px solid #d1d9e0; border-radius: 8px; padding: 12px 16px; }
aside h2 { font-size: 13px; text-transform: uppercase; letter-spacing: .06em; color: #59636e; margin: 0 0 8px; }
.pm-legend { list-style: none; padding: 0; margin: 0; }
.pm-legend li { display: flex; gap: 8px; align-items: flex-start; margin: 6px 0; }
.pm-legend li .sw, .pm-legend li .pm-n { margin-top: 2px; }
.sw { width: 22px; height: 14px; border-radius: 4px; border: 2px solid; flex: none; }
.sw-added { border-color: #1f883d; } .sw-modified { border-color: #bf8700; }
.sw-removed { border-color: #cf222e; border-style: dashed; } .sw-unchanged { border-color: #d1d9e0; }
.pm-note { color: #59636e; font-size: 12px; margin: 8px 0 0; }
.pm-n { display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; border-radius: 50%; background: #0969da; color: #fff; font-size: 12px; font-weight: 700; flex: none; }
.pm-steps { list-style: none; padding: 0; margin: 0; }
.pm-steps li { display: flex; gap: 10px; padding: 8px 6px; border-radius: 6px; }
.pm-steps li:hover, .pm-steps li.on { background: #ddf4ff; }
.pm-steps p { margin: 2px 0; color: #393f46; }
.pm-steps code, .pm-files a, .pm-files .pm-gone, details li { font: 12px ui-monospace, SFMono-Regular, Menlo, monospace; }
.pm-files { width: 100%; border-collapse: collapse; }
.pm-files th, .pm-files td { text-align: left; vertical-align: top; padding: 4px 6px; border-top: 1px solid #eaeef2; }
.pm-files a { word-break: break-all; }
.pm-gone { text-decoration: line-through; color: #59636e; }
details { margin-top: 8px; } summary { cursor: pointer; color: #0969da; }
a { color: #0969da; text-decoration: none; } a:hover { text-decoration: underline; }
.pm-hit { fill: transparent; cursor: pointer; }
.pm-diagram svg .chip, .pm-diagram svg .glyph, .pm-diagram svg .glyph-stroke { display: none; }
a:hover .pm-hit, .pm-hit.on { fill: rgba(9,105,218,.08); stroke: #0969da; stroke-width: 2; }
.pm-deleted .pm-hit { cursor: not-allowed; }
.pm-badge rect { fill: #0969da; stroke: #fff; stroke-width: 2; }
.pm-badge text { fill: #fff; font-size: 12px; font-weight: 700; text-anchor: middle; }
`;

// Hovering a step lights up its box, and the reverse.
const SCRIPT = `
const light = (node, on) =>
  document.querySelectorAll('[data-node="' + CSS.escape(node) + '"]').forEach(el => el.classList.toggle('on', on));
document.querySelectorAll('[data-node]').forEach(el => {
  el.addEventListener('mouseenter', () => light(el.dataset.node, true));
  el.addEventListener('mouseleave', () => light(el.dataset.node, false));
});`;

export function buildPage({ manifest, graph, sidecar, svg, head }) {
  const { broken, stale } = checkMap(graph, sidecar, head);
  if (broken.length) {
    const error = new Error(`Refusing to build the page:\n- ${broken.join("\n- ")}`);
    error.problems = broken;
    throw error;
  }
  const linked = graph.nodes.filter((n) => sidecar.targets?.[n.id]);
  const { byNode, warnings } = matchBoxes(findBoxes(svg), linked);
  const diagram = svg.replace(/<\/svg>\s*$/, `${overlay({ byNode, sidecar })}</svg>`);
  const banner = [
    stale.length ? `<div class="pm-banner"><b>This map is out of date.</b> ${stale.map(escapeHtml).join(" ")}</div>` : "",
    warnings.length
      ? `<div class="pm-banner"><b>Some boxes aren't clickable:</b><ul>${warnings.map((w) => `<li>${escapeHtml(w)}</li>`).join("")}</ul></div>`
      : "",
  ].join("");
  const mapped = sidecar.mapped ?? {};
  const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>${escapeHtml(graph.title)} · pr-map</title><style>${STYLE}</style></head>
<body>
<header>
  <h1>${escapeHtml(graph.title)}</h1>
  <p>${escapeHtml(graph.summary)}</p>
  <p>Mapped ${escapeHtml(mapped.at ?? "")} at <code>${escapeHtml((mapped.head ?? "").slice(0, 10))}</code>${mapped.pr ? ` · PR #${escapeHtml(mapped.pr)}` : ""}${mapped.branch ? ` · <code>${escapeHtml(mapped.branch)}</code>` : ""}. If clicking does nothing, let the browser open Cursor.</p>
</header>
${banner}
<main>
  <div class="pm-diagram">${diagram}</div>
  <aside>
    <section><h2>How to read this</h2>${LEGEND}</section>
    <section><h2>The story, in order</h2><ol class="pm-steps">${stepList(graph, sidecar)}</ol></section>
    <section><h2>Files</h2>${fileTable(sidecar)}</section>
  </aside>
</main>
<script>${SCRIPT}</script>
</body></html>`;
  return { html, warnings, stale };
}

// Reads one rendered drawing: its manifest, graph, top architecture SVG, and every view's SVG by view id.
export function loadDrawing(dir) {
  const read = (p) => JSON.parse(readFileSync(join(dir, p), "utf8"));
  const manifest = read("manifest.json");
  const graph = read("drawn.graph.json");
  const asset = overviewAsset(manifest, graph);
  if (!asset) throw new Error(`No architecture SVG in ${join(dir, "manifest.json")}.`);
  const svgs = {};
  for (const a of manifest.assets) if (a.lens === "architecture" && !svgs[a.view]) svgs[a.view] = readFileSync(join(dir, a.path), "utf8");
  return { manifest, graph, svg: readFileSync(join(dir, asset.path), "utf8"), svgs, asset };
}

function main(argv) {
  const [dir, sidecarPath] = argv;
  const headAt = argv.indexOf("--head");
  const head = headAt >= 0 ? argv[headAt + 1] : undefined;
  if (!dir || !sidecarPath) {
    console.error("Usage: node build_page.mjs <drawing-dir> <sidecar.json> --head <sha>");
    process.exit(2);
  }
  const sidecar = JSON.parse(readFileSync(sidecarPath, "utf8"));
  let result;
  try {
    result = buildPage({ ...loadDrawing(dir), sidecar, head });
  } catch (error) {
    console.error(error.message);
    process.exit(1);
  }
  // Written beside the page, then renamed over it, so a failed build never leaves half a page.
  const out = join(dir, "index.html");
  writeFileSync(`${out}.tmp`, result.html);
  renameSync(`${out}.tmp`, out);
  for (const w of result.warnings) console.warn(`! ${w}`);
  console.log(out);
}

// Bundled into the Cursor extension, import.meta.url is empty, and this file is a library there.
if (import.meta.url && process.argv[1] === fileURLToPath(import.meta.url)) main(process.argv.slice(2));
