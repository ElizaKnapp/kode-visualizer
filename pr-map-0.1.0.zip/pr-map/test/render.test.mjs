import { test } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { readCurrent, renderMap } from "../lib/render.mjs";

const fixture = join(dirname(fileURLToPath(import.meta.url)), "fixtures/example");
const graph = JSON.parse(readFileSync(join(fixture, "drawn.graph.json"), "utf8"));

function repo() {
  const root = mkdtempSync(join(tmpdir(), "pr-map-"));
  execFileSync("git", ["init", "-q"], { cwd: root });
  mkdirSync(join(root, ".pr-lens"));
  writeFileSync(join(root, ".pr-lens/graph.json"), JSON.stringify(graph));
  return root;
}

const sidecar = (overrides = {}) => ({
  version: 1,
  root: "/repo",
  mapped: { head: "abc", at: "2026-10-06 10:00" },
  targets: { "send-broadcast-bulk": { path: "functions/src/broadcast/sendBroadcastBulk.ts", line: 1 } },
  steps: [{ walkthroughStep: "batches-of-500", number: 1, node: "send-broadcast-bulk" }],
  files: [{ path: "functions/src/broadcast/sendBroadcastBulk.ts", step: 1, does: "Sends.", status: "added", group: "Story" }],
  ...overrides,
});

const writeSidecar = (root, side) => writeFileSync(join(root, ".pr-lens/pr-map.json"), JSON.stringify(side));

test("a good render becomes current, with its page and its own copy of the sidecar", () => {
  const root = repo();
  writeSidecar(root, sidecar());
  const { drawing, page } = renderMap(root, { head: "abc" });
  assert.ok(existsSync(page));
  assert.ok(existsSync(join(drawing, "pr-map.json")));
  assert.equal(join(root, ".pr-lens", readCurrent(root).drawing), drawing);
});

test("a render whose sidecar doesn't match the drawing changes nothing", () => {
  const root = repo();
  writeSidecar(root, sidecar());
  const first = renderMap(root, { head: "abc", now: new Date("2026-10-06T10:00:00Z") });
  writeSidecar(root, sidecar({ targets: { ghost: { path: "x.rb", line: 1 } } }));
  assert.throws(() => renderMap(root, { head: "abc", now: new Date("2026-10-06T11:00:00Z") }), /node "ghost"/);
  assert.equal(join(root, ".pr-lens", readCurrent(root).drawing), first.drawing);
});

test("leftover partial folders are cleared and only the newest maps are kept", () => {
  const root = repo();
  writeSidecar(root, sidecar());
  mkdirSync(join(root, ".pr-lens/maps/.cancelled.partial"), { recursive: true });
  for (let hour = 10; hour < 15; hour++) renderMap(root, { head: "abc", now: new Date(`2026-10-06T${hour}:00:00Z`) });
  const left = readdirSync(join(root, ".pr-lens/maps"));
  assert.equal(left.filter((n) => n.endsWith(".partial")).length, 0);
  assert.ok(left.length <= 4, left.join(", "));
  assert.match(readCurrent(root).drawing, /T140000/);
});

test(".pr-lens is kept out of git through info/exclude, never .gitignore", () => {
  const root = repo();
  writeSidecar(root, sidecar());
  renderMap(root, { head: "abc" });
  assert.equal(existsSync(join(root, ".gitignore")), false);
  assert.match(readFileSync(join(root, ".git/info/exclude"), "utf8"), /\.pr-lens\//);
});
