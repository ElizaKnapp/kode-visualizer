import { test } from "node:test";
import assert from "node:assert/strict";
import { decide } from "../lib/preflight.mjs";

const facts = (overrides = {}) => ({
  node: "20.20.2",
  prLensInstalled: true,
  root: "/repo",
  defaultBase: "origin/main",
  branch: "eliza/feature",
  ahead: 2,
  dirty: false,
  pr: { number: 42, headRefName: "eliza/feature", baseRefName: "main" },
  ...overrides,
});

test("a PR branch with commits is ready to map", () => {
  assert.deepEqual(decide(facts()), { ok: true, root: "/repo", branch: "eliza/feature", base: "origin/main", pr: 42 });
});

test("staged work with no commits still counts as work to map", () => {
  assert.equal(decide(facts({ ahead: 0, dirty: true })).ok, true);
});

test("the default branch asks which branch to map", () => {
  assert.equal(decide(facts({ branch: "main" })).ask, "not_pr_branch");
});

test("a branch with nothing on it asks which branch to map", () => {
  assert.equal(decide(facts({ ahead: 0, dirty: false })).ask, "not_pr_branch");
});

test("no PR yet asks, and --yes answers it", () => {
  const noPr = facts({ pr: { missing: true } });
  const asked = decide(noPr);
  assert.equal(asked.ask, "no_pr");
  assert.equal(asked.confirmable, true);
  assert.equal(decide(noPr, { yes: true }).ok, true);
});

test("GitHub being unreachable is its own question, not 'no PR'", () => {
  assert.equal(decide(facts({ pr: { error: "network" } })).ask, "gh_unavailable");
});

test("a PR number for another branch says to check it out, and can't be confirmed", () => {
  const result = decide(facts({ pr: { number: 7, headRefName: "someone/else", baseRefName: "main" } }), { prNumber: 7, yes: true });
  assert.equal(result.ask, "wrong_branch");
  assert.equal(result.confirmable, false);
  assert.match(result.message, /gh pr checkout 7/);
});

test("a PR number uses the PR's own base branch", () => {
  const result = decide(facts({ pr: { number: 9, headRefName: "eliza/feature", baseRefName: "release" } }), { prNumber: 9 });
  assert.equal(result.base, "origin/release");
});

test("an old Node is caught before anything else", () => {
  assert.equal(decide(facts({ node: "20.6.1" })).ask, "old_node");
  assert.equal(decide(facts({ node: "20.7.0" })).ok, true);
  assert.equal(decide(facts({ node: "18.19.0" })).ask, "old_node");
});

test("a missing PR Lens install says to run setup", () => {
  assert.match(decide(facts({ prLensInstalled: false })).message, /bin\/setup/);
});
