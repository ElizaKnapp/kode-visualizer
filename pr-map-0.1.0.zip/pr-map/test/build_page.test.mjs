import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { buildPage, cursorLink, findBoxes, matchBoxes } from "../build_page.mjs";

const dir = join(dirname(fileURLToPath(import.meta.url)), "fixtures/example");
const read = (name) => JSON.parse(readFileSync(join(dir, name), "utf8"));
const manifest = read("manifest.json");
const graph = read("drawn.graph.json");
const svg = readFileSync(join(dir, readdirSync(dir).find((f) => f.startsWith("overview-"))), "utf8");
const HEAD = "abc123";

const sidecar = (overrides = {}) => ({
  version: 1,
  root: "/repo",
  mapped: { head: HEAD, at: "2026-10-06T10:00:00Z" },
  targets: {
    "send-broadcast-bulk": { path: "functions/src/broadcast/sendBroadcastBulk.ts", line: 12 },
    "build-bulk-payload": { path: "lib/broadcast/buildBulkPayload.ts", line: 3 },
    "process-broadcast": { path: "functions/src/broadcast/processBroadcast.ts", deleted: true },
  },
  steps: [
    { walkthroughStep: "batches-of-500", number: 1, node: "send-broadcast-bulk" },
    { walkthroughStep: "old-path-goes-dark", number: 2, node: "process-broadcast" },
  ],
  fileTable: Array.from({ length: 13 }, (_, i) => ({ step: i + 1, path: `app/file_${i}.rb`, role: `Role ${i}` })),
  folded: [{ label: "Specs", paths: ["spec/a_spec.rb", "spec/b_spec.rb"] }],
  ...overrides,
});

const build = (side = sidecar(), svgText = svg) => buildPage({ manifest, graph, sidecar: side, svg: svgText, head: HEAD });
const count = (html, needle) => html.split(needle).length - 1;

test("every linked node gets exactly one link in the overview, with its path and line", () => {
  const { html, warnings } = build();
  assert.deepEqual(warnings, []);
  const diagram = html.slice(html.indexOf('<div class="pm-diagram">'), html.indexOf("<aside>"));
  assert.equal(count(diagram, 'href="cursor://file/repo/functions/src/broadcast/sendBroadcastBulk.ts:12"'), 1);
  assert.equal(count(diagram, 'href="cursor://file/repo/lib/broadcast/buildBulkPayload.ts:3"'), 1);
});

test("a deleted node gets a label, not a link", () => {
  const { html } = build();
  assert.match(html, /processBroadcast\.ts: deleted in this PR/);
  assert.doesNotMatch(html, /href="cursor:\/\/file\/repo\/functions\/src\/broadcast\/processBroadcast\.ts/);
});

test("step badges sit on their boxes", () => {
  const { html } = build();
  assert.equal(count(html, '<g class="pm-badge"'), 2);
});

test("a node that is two steps gets one badge with both numbers", () => {
  const steps = [
    { walkthroughStep: "batches-of-500", number: 1, node: "send-broadcast-bulk" },
    { walkthroughStep: "suppression-first", number: 5, node: "send-broadcast-bulk" },
  ];
  const { html } = build(sidecar({ steps }));
  assert.equal(count(html, '<g class="pm-badge"'), 1);
  assert.match(html, />1, 5<\/text>/);
});

test("a title cut off with an ellipsis still matches its label", () => {
  const boxes = [{ title: "ScheduleMastercardPop…", x: 0, y: 0, width: 10, height: 10 }];
  const { byNode, warnings } = matchBoxes(boxes, [{ id: "s", label: "ScheduleMastercardPopRetryActivity" }]);
  assert.deepEqual(warnings, []);
  assert.ok(byNode.s);
});

test("two labels that fit one cut-off title both lose their link and show the banner", () => {
  const boxes = [{ title: "ScheduleMastercardPop…", x: 0, y: 0, width: 10, height: 10 }];
  const nodes = [
    { id: "a", label: "ScheduleMastercardPopRetryActivity" },
    { id: "b", label: "ScheduleMastercardPopAlertJob" },
  ];
  const { byNode, warnings } = matchBoxes(boxes, nodes);
  assert.deepEqual(byNode, {});
  assert.equal(warnings.length, 2);
});

test("a label with no box shows the banner", () => {
  const renamed = svg.replace(">sendBroadcastBulk<", ">somethingElse<");
  const { html, warnings } = build(sidecar(), renamed);
  assert.equal(warnings.length, 1);
  assert.match(html, /class="pm-banner"/);
});

test("findBoxes pairs each title with the card around it", () => {
  const box = findBoxes(svg).find((b) => b.title === "POST /api/broadcasts/queue");
  assert.deepEqual({ x: box.x, y: box.y }, { x: 32, y: 206 });
});

test("paths with # or spaces are encoded", () => {
  assert.equal(cursorLink("/my repo", { path: "app/a#b.rb", line: 4 }), "cursor://file/my%20repo/app/a%23b.rb:4");
});

test("text from the graph is escaped", () => {
  const evil = { ...graph, title: "<script>alert(1)</script>" };
  const { html } = buildPage({ manifest, graph: evil, sidecar: sidecar(), svg, head: HEAD });
  assert.doesNotMatch(html, /<script>alert/);
});

test("an unknown node id refuses to build", () => {
  const side = sidecar({ targets: { ghost: { path: "x.rb", line: 1 } } });
  assert.throws(() => build(side), /node "ghost"/);
});

test("a sidecar from an older commit still builds, with an out-of-date banner", () => {
  const { html, stale } = build(sidecar({ mapped: { head: "old" } }));
  assert.equal(stale.length, 1);
  assert.match(html, /This map is out of date/);
});

test("a files list feeds the table: story files in step order, the rest grouped", () => {
  const files = [
    { path: "app/b.rb", step: 2, does: "Second.", status: "added", group: "Story" },
    { path: "app/a.rb", step: 1, does: "First.", status: "modified", group: "Story" },
    { path: "spec/a_spec.rb", does: "Tests a.", status: "added", group: "Specs" },
    { path: "docs/x.md", does: "Docs.", status: "modified", group: "Docs" },
  ];
  const { html } = build(sidecar({ files, fileTable: undefined, folded: undefined }));
  assert.ok(html.indexOf("app/a.rb") < html.indexOf("app/b.rb"));
  assert.match(html, /Specs \(1\)/);
  assert.match(html, /Docs \(1\)/);
});

test("the file table shows at most 10 rows, then +N more", () => {
  const { html } = build();
  const table = html.slice(html.indexOf('<table class="pm-files">'), html.indexOf("</table>"));
  assert.equal(count(table, "<tr><td>"), 10);
  assert.match(html, /\+3 more files/);
  assert.match(html, /Specs \(2\)/);
});

test("a step's own line beats its node's line", () => {
  const steps = [
    { walkthroughStep: "batches-of-500", number: 1, node: "send-broadcast-bulk" },
    { walkthroughStep: "suppression-first", number: 2, node: "send-broadcast-bulk", line: 40 },
  ];
  const { html } = build(sidecar({ steps }));
  const list = html.slice(html.indexOf('<ol class="pm-steps">'), html.indexOf("</ol>"));
  assert.match(list, /sendBroadcastBulk\.ts:12"/);
  assert.match(list, /sendBroadcastBulk\.ts:40"/);
});
