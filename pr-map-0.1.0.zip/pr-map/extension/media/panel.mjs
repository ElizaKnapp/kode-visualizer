// Runs inside the PR Map panel. One tab per view: "All", then one per flow. Each tab has its diagram and
// a side column. For a flow, the column shows the trigger, how the files fit together, the files to
// review in order, and what this PR changes in the file open in the editor. Every click goes back to
// the extension as an id; the extension decides what opens.
import { fit, focusBox, nameLayout, panBy, toScreen, zoomAt } from "../lib/view.mjs";

const vscode = acquireVsCodeApi();
const app = document.getElementById("app");
const saved = vscode.getState() ?? {};

let model = null;
let progress = null;
let activeFile = null;
let current = saved.current ?? null;
// Each tab keeps its own zoom, { view, userMoved }, for as long as the map is the same map.
let zoom = saved.zoom ?? {};
let emptyReason = "";
let emptyChecks = null;

const h = (tag, attrs = {}, ...children) => {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") el.className = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (v !== undefined && v !== null && v !== false) el.setAttribute(k, v === true ? "" : v);
  }
  for (const c of children.flat()) if (c !== null && c !== undefined && c !== false) el.append(c.nodeType ? c : document.createTextNode(String(c)));
  return el;
};
const send = (message) => vscode.postMessage(message);
const mapKey = () => (model ? `${model.title}@${model.mapped?.head ?? ""}` : null);
const save = () => vscode.setState({ current, zoom, legend: app.classList.contains("legend-open") });
const viewOf = (id) => model?.views.find((v) => v.id === id) ?? model?.views[0];

const TRIGGER_WORD = { api: "API call", webhook: "Webhook", job: "Job", event: "Event", schedule: "Schedule" };

// ---------- pieces

function legend() {
  return h("div", { class: "legend" },
    h("div", { class: "legend-row" }, h("span", { class: "sw sw-added" }), h("span", {}, h("b", {}, "Green"), ": new in this PR")),
    h("div", { class: "legend-row" }, h("span", { class: "sw sw-modified" }), h("span", {}, h("b", {}, "Amber"), ": changed in this PR")),
    h("div", { class: "legend-row" }, h("span", { class: "sw sw-removed" }), h("span", {}, h("b", {}, "Red, dashed, crossed out"), ": deleted in this PR")),
    h("div", { class: "legend-row" }, h("span", { class: "sw sw-unchanged" }), h("span", {}, h("b", {}, "Grey"), ": untouched code the change talks to")),
    h("div", { class: "legend-row" }, h("span", { class: "badge static" }, "2"), h("span", {}, h("b", {}, "Number"), ": the order to read the files in. Read 1 first.")),
    h("div", { class: "legend-row" }, h("span", {}, h("b", {}, "Arrows"), ": one part calls or sends to another. Dashed red is a call this PR removes.")),
    h("div", { class: "legend-row" }, h("span", {}, h("b", {}, "Click"), " a box or a file to open it above. Ctrl+scroll or pinch to zoom, drag to pan.")),
    h("p", { class: "note" }, "Arrows and summaries are an AI's reading of the code. They are not checked against it yet."),
  );
}

function toolbar() {
  const running = progress?.running;
  return h("div", { class: "toolbar" },
    h("div", { class: "title", title: model?.summary ?? "" }, model?.title ?? "PR Map"),
    h("div", { class: "spacer" }),
    running
      ? h("button", { onclick: () => send({ type: "cancel" }) }, "Cancel")
      : h("button", { class: "primary", onclick: () => send({ type: "mapThisPr" }) }, model ? "Redraw" : "Map this PR"),
    model && h("button", { title: "Zoom out", onclick: () => zoomButton(1 / 1.25) }, "−"),
    model && h("button", { title: "Zoom in", onclick: () => zoomButton(1.25) }, "+"),
    model && h("button", { title: "Fit the diagram to the panel", onclick: () => refit(true) }, "Fit"),
    model && h("button", { onclick: () => { app.classList.toggle("legend-open"); save(); } }, "How to read"),
    model && h("button", { class: "side-toggle", onclick: () => app.classList.toggle("side-open") }, "Details"),
  );
}

function tabs() {
  return h("div", { class: "tabs", role: "tablist" },
    model.views.map((v) =>
      h("button", {
        class: `tab${v.id === current ? " active" : ""}`,
        role: "tab",
        "aria-selected": v.id === current ? "true" : "false",
        title: v.kind === "flow" ? `${TRIGGER_WORD[v.trigger.kind] ?? "Trigger"}: ${v.trigger.name}` : "The whole PR",
        onclick: () => switchTo(v.id),
      }, v.title)));
}

function banners() {
  const items = [];
  if (progress?.running) items.push(h("div", { class: "banner info" }, h("b", {}, "Making a map… "), progress.lines.at(-1) ?? ""));
  else if (progress?.message) items.push(h("div", { class: `banner ${progress.outcome === "done" ? "ok" : "warn"}` }, progress.message, progress.outcome === "failed" ? h("button", { class: "link", onclick: () => send({ type: "showLog" }) }, "Show log") : null));
  if (model?.stale?.length) items.push(h("div", { class: "banner warn" }, h("b", {}, "This map is out of date. "), model.stale.join(" "), " ", h("button", { class: "link", onclick: () => send({ type: "mapThisPr" }) }, "Redraw?")));
  if (model?.warnings?.length) items.push(h("div", { class: "banner warn" }, h("b", {}, "Some boxes aren't clickable: "), model.warnings.join(" ")));
  return items;
}

function storyColumn(view) {
  return h("ol", { class: "story" },
    view.steps.map((s) =>
      h("li", {
        "data-node": s.node,
        class: s.clickable ? "clickable" : "",
        onclick: () => { if (s.clickable) send({ type: "open", step: s.number }); zoomTo(s.node); },
        onmouseenter: () => light(s.node, true),
        onmouseleave: () => light(s.node, false),
      },
      h("span", { class: "badge static" }, s.number),
      h("div", {}, h("div", { class: "heading" }, s.heading), h("div", { class: "body" }, s.body), s.path ? h("code", {}, s.path) : null)),
    ));
}

// What this PR changes in the file open in the editor, for the flow on screen.
function thisFile(view) {
  const box = h("section", { class: "this-file" }, h("h3", {}, "This file"));
  if (!activeFile) {
    box.append(h("p", { class: "muted" }, "Open a file from the list above."));
    return box;
  }
  const info = model.fileInfo?.[activeFile];
  const here = view.files.find((f) => f.path === activeFile);
  box.append(h("div", { class: "file-name" }, here ? h("span", { class: "badge static" }, here.number) : null, h("code", {}, activeFile)));
  if (here) {
    box.append(h("p", {}, here.changed || "No summary for this file."));
  } else if (info?.flows?.length) {
    box.append(h("p", { class: "muted" }, "This file isn't in this flow. It's in:"));
    box.append(h("ul", { class: "elsewhere" }, info.flows.map((f) => h("li", {}, h("button", { class: "link", onclick: () => switchTo(f.flow) }, f.title)))));
  } else if (info?.does) {
    box.append(h("p", {}, info.does), h("p", { class: "muted" }, "Not part of any flow."));
  } else {
    box.append(h("p", { class: "muted" }, "This PR doesn't change this file."));
  }
  return box;
}

function flowColumn(view) {
  const trigger = view.trigger;
  return h("div", { class: "flow-col" },
    h("div", { class: "flow-scroll" },
    h("section", { class: "trigger" },
      h("div", { class: "kicker" }, `Starts with: ${TRIGGER_WORD[trigger.kind] ?? "Trigger"}`),
      trigger.clickable
        ? h("button", { class: "link trigger-name", onclick: () => send({ type: "open", flow: view.id, trigger: true }) }, trigger.name)
        : h("code", { class: "trigger-name" }, trigger.name)),
    h("section", {}, h("h3", {}, "How it fits together"), h("p", {}, view.summary)),
    h("section", {},
      h("h3", {}, "Files to review, in order"),
      h("ol", { class: "files" },
        view.files.map((f) =>
          h("li", {
            class: `clickable${f.path === activeFile ? " active" : ""}`,
            "data-node": f.node ?? "",
            onclick: () => { send({ type: "open", flow: view.id, file: f.index }); if (f.node) zoomTo(f.node); },
            onmouseenter: () => f.node && light(f.node, true),
            onmouseleave: () => f.node && light(f.node, false),
          },
          h("span", { class: "badge static" }, f.number),
          h("div", {}, h("div", { class: "heading" }, f.name), h("code", {}, f.path))))))),
    thisFile(view),
  );
}

// ---------- drawing

let viewportEl, stageEl, labelsEl, dragged = false;

function render() {
  app.replaceChildren();
  app.append(toolbar());
  if (!model) {
    app.append(...banners(), h("div", { class: "empty" }, emptyContent()));
    return;
  }
  const view = viewOf(current);
  current = view.id;
  // Tells the extension which tab is on screen, so Cursor's chat knows the current flow.
  if (view.kind === "flow") send({ type: "tab", flow: view.id });
  app.append(tabs(), ...banners());

  const stage = h("div", { class: "stage" });
  stage.innerHTML = view.svg;
  const hits = h("div", { class: "hits" });
  for (const box of view.boxes) {
    hits.append(h("div", {
      class: `hit${box.clickable ? " clickable" : ""}${box.deleted ? " deleted" : ""}`,
      "data-node": box.id,
      title: `${box.label}${box.subtitle ? `\n${box.subtitle}` : ""}${box.deleted ? "\nDeleted in this PR" : box.clickable ? "\nClick to open" : ""}`,
      style: `left:${box.x}px;top:${box.y}px;width:${box.width}px;height:${box.height}px`,
      onclick: (e) => { if (box.clickable && !dragged) openBox(view, box); e.stopPropagation(); },
      onmouseenter: () => light(box.id, true),
      onmouseleave: () => light(box.id, false),
    }));
  }
  stage.append(hits);
  const labels = h("div", { class: "labels" });
  const viewport = h("div", { class: "viewport" }, stage, labels);
  app.append(h("div", { class: "body-grid" },
    h("div", { class: "diagram-card" }, viewport),
    h("aside", { class: view.kind === "flow" ? "flow-aside" : "" }, h("div", { class: "legend-wrap" }, legend()), view.kind === "flow" ? flowColumn(view) : storyColumn(view)),
  ));
  wireViewport(viewport, stage, labels);
}

// A box in a flow opens that flow's file for it, at its line in this flow; otherwise the box's own file.
function openBox(view, box) {
  const file = view.kind === "flow" ? view.files.find((f) => f.node === box.id) : null;
  send(file ? { type: "open", flow: view.id, file: file.index } : { type: "open", node: box.id });
}

function emptyContent() {
  const lines = [h("p", {}, emptyReason || "Loading…")];
  if (emptyChecks?.some((c) => !c.ok)) {
    lines.push(h("p", {}, "Before Map this PR can run:"));
    lines.push(h("ul", { class: "checks" }, emptyChecks.map((c) => h("li", { class: c.ok ? "ok" : "bad" }, c.ok ? "✓ " : "✗ ", c.name, c.fix ? h("div", { class: "fix" }, c.fix) : null))));
  }
  return lines;
}

// Matches .badge in panel.css: 18 px round, wider for "1, 5".
const badgeWidth = (box) => Math.max(18, 10 + 6.5 * box.numbers.join(", ").length);
const state = () => (zoom[current] ??= { view: null, userMoved: false });
const size = () => ({ width: viewportEl.clientWidth, height: viewportEl.clientHeight });

function apply() {
  const { view } = state();
  if (!view) return;
  const shown = viewOf(current);
  stageEl.style.transform = `translate(${view.x}px, ${view.y}px) scale(${view.scale})`;
  app.classList.toggle("zoomed-out", view.scale < 1);
  const layout = new Map(nameLayout(shown.boxes, view).map((l) => [l.id, l]));
  labelsEl.replaceChildren();
  for (const box of shown.boxes) {
    const s = toScreen(box, view);
    const name = layout.get(box.id);
    if (name?.show) {
      // A badge sits on the box's top-left corner, so a numbered box's name starts after it.
      const shift = box.numbers.length ? Math.max(0, s.x - 8 + badgeWidth(box) + 3 - name.x) : 0;
      if (name.width - shift > 24) {
        labelsEl.append(h("div", { class: "name", style: `left:${name.x + shift}px;top:${name.y}px;max-width:${name.width - shift}px` }, box.label));
      }
    }
    if (box.numbers.length) labelsEl.append(h("div", { class: "badge", style: `left:${s.x - 8}px;top:${s.y - 9}px` }, box.numbers.join(", ")));
  }
  save();
}

function refit(byHand = false) {
  const st = state();
  st.view = fit(viewOf(current).size, size());
  if (byHand) st.userMoved = false;
  apply();
}

function zoomButton(factor) {
  const s = size();
  const st = state();
  st.view = zoomAt(st.view, factor, { x: s.width / 2, y: s.height / 2 });
  st.userMoved = true;
  apply();
}

function zoomTo(nodeId) {
  const box = viewOf(current).boxes.find((b) => b.id === nodeId);
  if (!box) return;
  const st = state();
  st.view = focusBox(box, size(), st.view);
  st.userMoved = true;
  stageEl.classList.add("animate");
  apply();
  setTimeout(() => stageEl.classList.remove("animate"), 260);
  light(nodeId, true);
  setTimeout(() => light(nodeId, false), 1200);
}

function light(nodeId, on) {
  if (!nodeId) return;
  document.querySelectorAll(`[data-node="${CSS.escape(nodeId)}"]`).forEach((el) => el.classList.toggle("on", on));
}

function switchTo(id) {
  current = id;
  save();
  render();
}

const resizer = new ResizeObserver(() => {
  if (!model || !viewportEl) return;
  if (state().userMoved && state().view) apply();
  else refit();
});

function wireViewport(viewport, stage, labels) {
  viewportEl = viewport;
  stageEl = stage;
  labelsEl = labels;
  // Same tab drawn again (a banner, a new active file): keep where you were. A tab seen for the first
  // time fits.
  if (state().view) requestAnimationFrame(apply);
  else requestAnimationFrame(() => refit());
  resizer.disconnect();
  resizer.observe(viewport);

  viewport.addEventListener("wheel", (e) => {
    e.preventDefault();
    const rect = viewport.getBoundingClientRect();
    const st = state();
    // A trackpad pinch arrives as a wheel event with ctrlKey set.
    if (e.ctrlKey || e.metaKey) st.view = zoomAt(st.view, Math.exp(-e.deltaY * 0.01), { x: e.clientX - rect.left, y: e.clientY - rect.top });
    else st.view = panBy(st.view, -e.deltaX, -e.deltaY);
    st.userMoved = true;
    apply();
  }, { passive: false });
  viewport.addEventListener("pointerdown", (e) => {
    drag = { x: e.clientX, y: e.clientY, view: state().view };
    dragged = false;
  });
}

// Dragging is tracked on the window, once, so a drag that leaves the panel still ends.
let drag = null;
window.addEventListener("pointermove", (e) => {
  if (!drag || !viewportEl) return;
  const dx = e.clientX - drag.x;
  const dy = e.clientY - drag.y;
  if (!dragged && Math.hypot(dx, dy) < 4) return;
  dragged = true;
  viewportEl.classList.add("dragging");
  const st = state();
  st.view = panBy(drag.view, dx, dy);
  st.userMoved = true;
  apply();
});
window.addEventListener("pointerup", () => {
  drag = null;
  viewportEl?.classList.remove("dragging");
  setTimeout(() => (dragged = false), 0);
});

// ---------- messages from the extension

window.addEventListener("message", ({ data }) => {
  if (data.type === "model") {
    model = data.model;
    // A different map (new title or commit) starts fresh. The same map keeps your tabs and zoom.
    if (zoom.__key !== mapKey()) zoom = { __key: mapKey() };
    if (saved.legend) app.classList.add("legend-open");
    render();
  } else if (data.type === "empty") {
    model = null;
    emptyReason = data.reason;
    emptyChecks = data.checks ?? null;
    render();
  } else if (data.type === "progress") {
    progress = data.progress;
    render();
  } else if (data.type === "stale") {
    if (model) {
      model.stale = data.reasons;
      render();
    }
  } else if (data.type === "activeFile") {
    activeFile = data.path;
    if (model) render();
  } else if (data.type === "fit" && model) {
    refit(true);
  }
});

send({ type: "ready" });
