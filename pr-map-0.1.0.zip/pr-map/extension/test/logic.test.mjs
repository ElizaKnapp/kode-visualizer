import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { fit, focusBox, nameLayout, zoomAt } from "../lib/view.mjs";
import { buildModel, resolveOpen, safePath, sanitizeSvg } from "../lib/model.mjs";
import { groupFiles, parseNameStatus } from "../lib/files.mjs";
import { staleReasons } from "../lib/staleness.mjs";

const fixture = join(dirname(fileURLToPath(import.meta.url)), "../../test/fixtures/example");
const graph = JSON.parse(readFileSync(join(fixture, "drawn.graph.json"), "utf8"));
const svg = readFileSync(join(fixture, readdirSync(fixture).find((f) => f.startsWith("overview-"))), "utf8");
const sidecar = (overrides = {}) => ({
  root: "/repo",
  mapped: { head: "abc", branch: "feature", at: "2026-10-06T10:00:00Z" },
  targets: {
    "send-broadcast-bulk": { path: "functions/src/broadcast/sendBroadcastBulk.ts", line: 12 },
    "process-broadcast": { path: "functions/src/broadcast/processBroadcast.ts", deleted: true },
  },
  steps: [
    { walkthroughStep: "batches-of-500", number: 1, node: "send-broadcast-bulk" },
    { walkthroughStep: "suppression-first", number: 2, node: "send-broadcast-bulk", line: 40 },
  ],
  ...overrides,
});
const model = (side = sidecar(), extra = {}) => buildModel({ graph, sidecar: side, svg, head: "abc", root: "/repo", branch: "feature", ...extra });

// --- fit and zoom

test("fit puts the whole diagram inside a wide, short panel", () => {
  const view = fit({ width: 1708, height: 988 }, { width: 1200, height: 300 });
  assert.ok(988 * view.scale <= 300 - 32 + 1e-9);
  assert.ok(1708 * view.scale <= 1200);
  assert.ok(Math.abs(view.x - (1200 - 1708 * view.scale) / 2) < 1e-9);
});

test("fit puts the whole diagram inside a tall, narrow panel", () => {
  const view = fit({ width: 1708, height: 988 }, { width: 400, height: 900 });
  assert.ok(1708 * view.scale <= 400 - 32 + 1e-9);
});

test("zooming keeps the point under the cursor in place", () => {
  const view = { scale: 0.5, x: 10, y: 20 };
  const next = zoomAt(view, 2, { x: 300, y: 200 });
  const before = { x: (300 - view.x) / view.scale, y: (200 - view.y) / view.scale };
  const after = { x: (300 - next.x) / next.scale, y: (200 - next.y) / next.scale };
  assert.deepEqual(after, before);
});

test("focusing a box centers it and never zooms further out", () => {
  const box = { x: 456, y: 424, width: 372, height: 62 };
  const current = { scale: 0.3, x: 0, y: 0 };
  const view = focusBox(box, { width: 1000, height: 300 }, current);
  assert.ok(view.scale >= 0.3);
  assert.ok(Math.abs((box.x + box.width / 2) * view.scale + view.x - 500) < 1e-9);
});

// --- names

test("names show at a fitted size where the box is tall enough", () => {
  const boxes = [{ id: "a", x: 0, y: 0, width: 372, height: 52 }];
  assert.equal(nameLayout(boxes, { scale: 0.26, x: 0, y: 0 })[0].show, true);
  assert.equal(nameLayout(boxes, { scale: 0.2, x: 0, y: 0 })[0].show, false);
});

test("from 1x up, our names hide so PR Lens's own show", () => {
  const boxes = [{ id: "a", x: 0, y: 0, width: 372, height: 52 }];
  assert.equal(nameLayout(boxes, { scale: 1, x: 0, y: 0 })[0].show, false);
});

test("two names that would overlap: the second hides", () => {
  const boxes = [
    { id: "a", x: 0, y: 0, width: 372, height: 62 },
    { id: "b", x: 0, y: 5, width: 372, height: 62 },
  ];
  const [a, b] = nameLayout(boxes, { scale: 0.5, x: 0, y: 0 });
  assert.equal(a.show, true);
  assert.equal(b.show, false);
});

// --- model

test("the model carries boxes, badges and steps, but no paths", () => {
  const m = model();
  const all = m.views[0];
  const bulk = all.boxes.find((b) => b.id === "send-broadcast-bulk");
  assert.deepEqual(bulk.numbers, [1, 2]);
  assert.equal(bulk.clickable, true);
  assert.equal(all.boxes.find((b) => b.id === "process-broadcast").deleted, true);
  assert.equal(JSON.stringify(all.boxes).includes("functions/src"), false);
});

test("a map from another folder or branch is refused", () => {
  assert.match(model(sidecar({ root: "/elsewhere" })).broken[0], /made in \/elsewhere/);
  assert.match(model(sidecar(), { branch: "main" }).broken[0], /for branch feature/);
});

test("an older commit is stale, not broken", () => {
  const m = model(sidecar(), { head: "def" });
  assert.equal(m.broken, undefined);
  assert.equal(m.stale.length, 1);
});

test("paths that leave the repo are dropped", () => {
  assert.equal(safePath("../secrets"), null);
  assert.equal(safePath("/etc/passwd"), null);
  assert.equal(safePath("app/a.rb"), "app/a.rb");
  const m = model(sidecar({ targets: { "send-broadcast-bulk": { path: "../../x", line: 1 } } }));
  assert.equal(m.views[0].boxes.find((b) => b.id === "send-broadcast-bulk").clickable, false);
  assert.match(m.warnings.join(), /leaves the repo/);
});

test("clicks resolve only through the map, and a step's own line wins", () => {
  assert.deepEqual(resolveOpen(sidecar(), { node: "send-broadcast-bulk" }), { path: "functions/src/broadcast/sendBroadcastBulk.ts", line: 12 });
  assert.equal(resolveOpen(sidecar(), { step: 2 }).line, 40);
  assert.equal(resolveOpen(sidecar(), { node: "process-broadcast" }), null);
  assert.equal(resolveOpen(sidecar(), { node: "nope" }), null);
});

test("the SVG loses scripts, handlers and outside links", () => {
  const clean = sanitizeSvg('<svg><script>x()</script><a href="https://evil"><rect onclick="x()"/></a><use href="#ok"/></svg>');
  assert.doesNotMatch(clean, /script|onclick|evil/);
  assert.match(clean, /href="#ok"/);
});

// --- files

test("git's name-status lines parse, renames keep the old path", () => {
  assert.deepEqual(parseNameStatus("M\tapp/a.rb\nR087\tapp/old.rb\tapp/new.rb\nA\tapp/b.rb\n"), [
    { status: "modified", path: "app/a.rb" },
    { status: "renamed", oldPath: "app/old.rb", path: "app/new.rb" },
    { status: "added", path: "app/b.rb" },
  ]);
});

test("every changed file shows exactly once, in story order, then collapsed groups, then extras", () => {
  const files = [
    { path: "app/b.rb", step: 2, does: "B" },
    { path: "app/a.rb", step: 1, does: "A" },
    { path: "app/a.rb", step: 5, does: "A again" },
    { path: "spec/a_spec.rb", group: "Specs", does: "tests" },
    { path: "db/schema.rb", does: "schema" },
  ];
  const changed = parseNameStatus("M\tapp/a.rb\nA\tapp/b.rb\nA\tspec/a_spec.rb\nM\tdb/schema.rb\nM\tapp/forgotten.rb\n");
  const groups = groupFiles({ files, steps: [{ number: 1 }, { number: 2 }], headings: { 1: "First", 2: "Second" } }, changed);
  assert.deepEqual(groups.map((g) => g.label), ["1. First", "2. Second", "Specs", "Other", "Not in the map"]);
  assert.deepEqual(groups.map((g) => g.collapsed), [false, false, true, true, false]);
  const all = groups.flatMap((g) => g.files.map((f) => f.path));
  assert.equal(new Set(all).size, all.length);
  assert.ok(all.includes("app/forgotten.rb"));
});

// --- staleness

test("a moved branch or a saved mapped file makes the map stale", () => {
  const at = Date.parse("2026-10-06T10:00:00Z");
  assert.equal(staleReasons({ mappedHead: "a", head: "a", mappedAt: "2026-10-06T10:00:00Z" }).length, 0);
  assert.equal(staleReasons({ mappedHead: "a", head: "b" }).length, 1);
  const covered = new Set(["app/a.rb"]);
  assert.equal(staleReasons({ mappedAt: "2026-10-06T10:00:00Z", saves: [{ path: "app/a.rb", at: at + 1 }], covered }).length, 1);
  assert.equal(staleReasons({ mappedAt: "2026-10-06T10:00:00Z", saves: [{ path: "app/a.rb", at: at - 1 }], covered }).length, 0);
  assert.equal(staleReasons({ mappedAt: "2026-10-06T10:00:00Z", saves: [{ path: "other.rb", at: at + 1 }], covered }).length, 0);
});

// --- flows

const flows = [
  {
    id: "send",
    title: "Queue → bulk send",
    view: "new-batch-path",
    trigger: { kind: "api", name: "POST /api/broadcasts/queue", path: "app/api/queue/route.ts", line: 3 },
    summary: "The route queues a broadcast. The bulk sender builds batches and posts them.",
    files: [
      { path: "functions/src/broadcast/sendBroadcastBulk.ts", line: 12, node: "send-broadcast-bulk", changed: "New. Sends 500 at a time." },
      { path: "lib/broadcast/buildBulkPayload.ts", line: 3, node: "build-bulk-payload", changed: "New. Builds one batch." },
    ],
  },
  {
    id: "retire",
    title: "Old single send",
    view: "retired-path",
    trigger: { kind: "event", name: "Firestore broadcast created" },
    summary: "The old path, now gone.",
    files: [{ path: "functions/src/broadcast/sendBroadcastBulk.ts", line: 1, node: "send-broadcast-bulk", changed: "Replaces processBroadcast." }],
  },
];
const svgs = Object.fromEntries(readdirSync(fixture).filter((f) => f.endsWith(".svg")).map((f) => [f.replace(/-light-.*$/, ""), readFileSync(join(fixture, f), "utf8")]));

test("each flow becomes its own tab, numbered in reading order, with no All tab", () => {
  const m = buildModel({ graph, sidecar: sidecar({ flows }), svg, svgs, head: "abc", root: "/repo", branch: "feature" });
  assert.deepEqual(m.views.map((v) => v.id), ["send", "retire"]);
  const send = m.views[0];
  assert.equal(send.trigger.name, "POST /api/broadcasts/queue");
  assert.equal(send.trigger.clickable, true);
  assert.deepEqual(send.files.map((f) => f.number), [1, 2]);
  assert.deepEqual(send.boxes.find((b) => b.id === "build-bulk-payload").numbers, [2]);
  assert.notEqual(send.svg, m.views[1].svg);
});

test("a map with no flows still shows one All tab", () => {
  assert.deepEqual(model().views.map((v) => v.id), ["all"]);
});

test("a file in two flows keeps one summary per flow", () => {
  const m = buildModel({ graph, sidecar: sidecar({ flows }), svg, svgs, head: "abc", root: "/repo", branch: "feature" });
  const info = m.fileInfo["functions/src/broadcast/sendBroadcastBulk.ts"];
  assert.deepEqual(info.flows.map((f) => [f.flow, f.changed]), [["send", "New. Sends 500 at a time."], ["retire", "Replaces processBroadcast."]]);
});

test("a flow naming a view that wasn't drawn is refused", () => {
  const bad = [{ ...flows[0], view: "nope" }];
  assert.match(model(sidecar({ flows: bad })).broken.join(), /view "nope"/);
});

test("flow clicks resolve to the flow's file or trigger, nothing else", () => {
  const side = sidecar({ flows });
  assert.deepEqual(resolveOpen(side, { flow: "send", file: 1 }), { path: "lib/broadcast/buildBulkPayload.ts", line: 3 });
  assert.deepEqual(resolveOpen(side, { flow: "send", trigger: true }), { path: "app/api/queue/route.ts", line: 3 });
  assert.equal(resolveOpen(side, { flow: "retire", trigger: true }), null);
  assert.equal(resolveOpen(side, { flow: "nope", file: 0 }), null);
});

test("the sidebar groups by flow, a shared file shows in each, and the rest stay collapsed", () => {
  const files = [
    { path: "functions/src/broadcast/sendBroadcastBulk.ts", does: "Sends." },
    { path: "lib/broadcast/buildBulkPayload.ts", does: "Builds." },
    { path: "spec/x_spec.rb", group: "Specs", does: "tests" },
  ];
  const groups = groupFiles({ files, flows }, null);
  assert.deepEqual(groups.map((g) => [g.label, g.collapsed]), [["Queue → bulk send", false], ["Old single send", false], ["Specs", true]]);
  assert.equal(groups[1].files[0].changed, "Replaces processBroadcast.");
});
