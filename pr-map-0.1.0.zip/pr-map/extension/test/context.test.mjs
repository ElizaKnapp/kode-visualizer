import { test } from "node:test";
import assert from "node:assert/strict";
import { buildContext, MAX_SELECTION_LINES, versionLabel } from "../lib/context.mjs";

const model = {
  summary: "Retries card pulls when Mastercard says the money is back.",
  views: [
    {
      id: "retry", kind: "flow", title: "RETRY_NOW → retry charge",
      trigger: { kind: "webhook", name: "POST /webhooks/mastercard-pop" },
      summary: "The webhook enqueues the job. The job matches, then schedules.",
      files: [
        { number: 1, path: "app/jobs/alert_job.rb", changed: "Schedules inside the lock." },
        { number: 2, path: "app/activities/schedule.rb", changed: "New. Books a refresh." },
      ],
    },
    {
      id: "hold", kind: "flow", title: "Hold → skip charge",
      trigger: { kind: "job", name: "Smart-card slot" },
      summary: "Skips charges for 24 hours.",
      files: [{ number: 1, path: "app/activities/payment.rb", changed: "Checks the hold." }],
    },
  ],
  fileInfo: {
    "app/jobs/alert_job.rb": { does: "Matches alerts.", flows: [{ flow: "retry", title: "RETRY_NOW → retry charge", number: 1, changed: "Schedules inside the lock." }] },
    "app/activities/payment.rb": { does: "Charges the card.", flows: [{ flow: "hold", title: "Hold → skip charge", number: 1, changed: "Checks the hold." }] },
    "db/schema.rb": { does: "Adds an enum value.", flows: [] },
  },
};
const map = { model, sidecar: { root: "/repo", mapped: { pr: 6972, branch: "eliza/pop", head: "eaa980f26abb" } }, mergeBase: "7da878fd633a" };

test("no map says so", () => {
  assert.match(buildContext(null), /No PR map is loaded/);
});

test("the current flow, its trigger, and its files in order", () => {
  const md = buildContext(map, { flow: "retry" });
  assert.match(md, /PR: #6972 on branch `eliza\/pop`/);
  assert.match(md, /git diff 7da878fd633a -- <file>/);
  assert.match(md, /## Current flow: RETRY_NOW → retry charge/);
  assert.match(md, /webhook `POST \/webhooks\/mastercard-pop`/);
  assert.ok(md.indexOf("1. `app/jobs/alert_job.rb`") < md.indexOf("2. `app/activities/schedule.rb`"));
  assert.match(md, /Other flows in this PR: Hold → skip charge/);
});

test("a file in the current flow gets its summary for this flow", () => {
  assert.match(buildContext(map, { flow: "retry", file: "app/jobs/alert_job.rb" }), /File 1 of the current flow\. What this PR changes in it for this flow: Schedules inside the lock\./);
});

test("a file in another flow says which", () => {
  assert.match(buildContext(map, { flow: "retry", file: "app/activities/payment.rb" }), /Not in the current flow\. It's in: "Hold → skip charge" \(file 1\)/);
});

test("a changed file in no flow, and an unchanged file", () => {
  assert.match(buildContext(map, { flow: "retry", file: "db/schema.rb" }), /not in any flow\. What it does: Adds an enum value\./);
  assert.match(buildContext(map, { flow: "retry", file: "README.md" }), /This PR doesn't change this file/);
});

test("selections carry their lines and which version they're from", () => {
  const md = buildContext(map, { flow: "retry", selection: { path: "app/activities/schedule.rb", startLine: 50, endLine: 52, text: "def x\n  y\nend", version: versionLabel("7da878fd633a", "7da878fd633a") } });
  assert.match(md, /`app\/activities\/schedule\.rb`, lines 50-52, from the base version, before this PR\./);
  assert.match(md, /def x\n  y\nend/);
});

test("each diff side gets its own label", () => {
  assert.match(versionLabel(undefined, "abc"), /working copy/);
  assert.match(versionLabel("7da878f", "7da878fd633a"), /base version/);
  assert.equal(versionLabel("HEAD", "abc"), "the last commit");
  assert.equal(versionLabel("", "abc"), "the staged copy");
  assert.equal(versionLabel("~", "abc"), "the staged copy");
});

test("a huge selection is cut, and says so", () => {
  const text = Array.from({ length: 400 }, (_, i) => `line ${i + 1}`).join("\n");
  const md = buildContext(map, { selection: { path: "a.rb", startLine: 1, endLine: 400, text, version: "your working copy" } });
  assert.match(md, new RegExp(`lines 1-${MAX_SELECTION_LINES},`));
  assert.match(md, /The selection was 400 lines/);
  assert.doesNotMatch(md, /line 301/);
});

test("backticks in a selection can't break out of its code block", () => {
  const md = buildContext(map, { selection: { path: "a.md", startLine: 1, endLine: 1, text: "````\nnot code", version: "x" } });
  assert.match(md, /`````\n````\nnot code\n`````/);
});

test("an out-of-date map says to trust git diff", () => {
  assert.match(buildContext(map, {}, ["You saved app/x.rb after this map was made."]), /\*\*This map is out of date\.\*\* You saved app\/x\.rb.*Trust `git diff`/);
});
