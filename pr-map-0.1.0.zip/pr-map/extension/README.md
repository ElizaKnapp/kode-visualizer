# PR Map

Shows the map `/pr-map` makes: the PR's story as a diagram in the bottom panel, and every changed file
with what it does in the sidebar. Local only. See `../SKILL.md`.
