import { randomBytes } from "node:crypto";
import * as vscode from "vscode";

// Messages the panel sends. Clicks carry ids from the model, never paths.
export type FromPanel =
  | { type: "ready" }
  | { type: "open"; node?: string; step?: number; flow?: string; file?: number; trigger?: boolean }
  | { type: "mapThisPr" }
  | { type: "cancel" }
  | { type: "showLog" }
  | { type: "tab"; flow: string };

export class MapPanel implements vscode.WebviewViewProvider {
  private view: vscode.WebviewView | null = null;
  private last: unknown = { type: "loading" };
  private lastActive: unknown = null;

  constructor(
    private readonly extensionUri: vscode.Uri,
    private readonly onMessage: (message: FromPanel) => void,
  ) {}

  resolveWebviewView(view: vscode.WebviewView) {
    this.view = view;
    const dist = vscode.Uri.joinPath(this.extensionUri, "dist");
    const media = vscode.Uri.joinPath(this.extensionUri, "media");
    view.webview.options = { enableScripts: true, localResourceRoots: [dist, media] };
    view.webview.html = this.html(view.webview, dist, media);
    view.webview.onDidReceiveMessage((message: FromPanel) => {
      if (message.type === "ready") {
        this.post(this.last);
        if (this.lastActive) this.post(this.lastActive);
      }
      else this.onMessage(message);
    });
    view.onDidDispose(() => (this.view = null));
  }

  post(message: unknown) {
    const kind = (message as { type: string }).type;
    // Progress and banners go on top of the last full message, so a reopened panel gets the map back.
    if (kind === "activeFile") this.lastActive = message;
    else if (kind !== "progress" && kind !== "stale" && kind !== "fit") this.last = message;
    this.view?.webview.postMessage(message);
  }

  reveal() {
    this.view?.show?.(true);
  }

  private html(webview: vscode.Webview, dist: vscode.Uri, media: vscode.Uri): string {
    const nonce = randomBytes(16).toString("base64");
    const script = webview.asWebviewUri(vscode.Uri.joinPath(dist, "panel.js"));
    const style = webview.asWebviewUri(vscode.Uri.joinPath(media, "panel.css"));
    // The SVG comes in as text and is set with innerHTML, so its inline styles need 'unsafe-inline'
    // for style only. Scripts run only with this page's nonce.
    const csp = [
      "default-src 'none'",
      `img-src ${webview.cspSource} data:`,
      `style-src ${webview.cspSource} 'unsafe-inline'`,
      `script-src 'nonce-${nonce}'`,
      `font-src ${webview.cspSource}`,
    ].join("; ");
    return `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="${csp}">
<link rel="stylesheet" href="${style}">
</head><body>
<div id="app"></div>
<script nonce="${nonce}" src="${script}"></script>
</body></html>`;
  }
}
