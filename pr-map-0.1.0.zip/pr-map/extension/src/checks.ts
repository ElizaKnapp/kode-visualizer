import { existsSync } from "node:fs";
import { prLensBin, skillDirFor } from "./skill";
import { run, which } from "./shell";

export interface Check {
  name: string;
  ok: boolean;
  fix?: string;
}

const MIN_NODE = [20, 7];

// What Map this PR needs. Looked up from here, not from a Node script, so "Node is missing" can be said.
export async function firstRunChecks(root: string): Promise<Check[]> {
  const checks: Check[] = [];

  const node = which("node");
  if (!node) {
    checks.push({ name: "Node", ok: false, fix: "Install Node 20.7 or newer: `brew install node`." });
  } else {
    const version = (await run(node, ["--version"])).stdout.trim().replace(/^v/, "");
    const [major, minor] = version.split(".").map(Number);
    const ok = major > MIN_NODE[0] || (major === MIN_NODE[0] && minor >= MIN_NODE[1]);
    checks.push({ name: `Node ${version}`, ok, fix: ok ? undefined : "Install Node 20.7 or newer: `brew install node`." });
  }

  const claude = which("claude");
  if (!claude) {
    checks.push({ name: "Claude Code", ok: false, fix: "Install Claude Code, then reopen Cursor." });
  } else {
    const status = await run(claude, ["auth", "status"]);
    let loggedIn = false;
    try {
      loggedIn = JSON.parse(status.stdout).loggedIn === true;
    } catch {
      loggedIn = false;
    }
    checks.push({ name: "Claude Code signed in", ok: loggedIn, fix: loggedIn ? undefined : "Run `claude` in a terminal and sign in." });
  }

  const gh = which("gh");
  const ghOk = gh ? (await run(gh, ["auth", "status"])).code === 0 : false;
  checks.push({ name: "GitHub CLI signed in", ok: ghOk, fix: ghOk ? undefined : gh ? "Run `gh auth login`." : "Install the GitHub CLI: `brew install gh`, then `gh auth login`." });

  const skill = skillDirFor(root);
  checks.push({
    name: "pr-map skill",
    ok: Boolean(skill),
    fix: skill ? undefined : "Put the pr-map skill folder at `~/.claude/skills/pr-map` (see its INSTALL.md), then reload Cursor.",
  });
  if (skill) {
    const installed = existsSync(prLensBin(skill));
    checks.push({ name: "PR Lens installed", ok: installed, fix: installed ? undefined : `Run \`${skill}/bin/setup\` once.` });
  }
  return checks;
}
