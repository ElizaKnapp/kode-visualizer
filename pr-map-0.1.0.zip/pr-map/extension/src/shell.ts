import { execFile } from "node:child_process";
import { existsSync } from "node:fs";
import { homedir } from "node:os";
import { delimiter, join } from "node:path";

// Cursor started from the Dock can have a shorter PATH than your terminal. These are where Homebrew,
// the Claude installer and nvm usually put things, so a missing tool is looked for there too.
const EXTRA_PATHS = ["/opt/homebrew/bin", "/usr/local/bin", join(homedir(), ".local/bin"), join(homedir(), ".claude/local")];

export function shellPath(): string {
  const parts = (process.env.PATH ?? "").split(delimiter).filter(Boolean);
  for (const extra of EXTRA_PATHS) if (!parts.includes(extra)) parts.push(extra);
  return parts.join(delimiter);
}

export const shellEnv = (): NodeJS.ProcessEnv => ({ ...process.env, PATH: shellPath() });

export function which(name: string): string | null {
  for (const dir of shellPath().split(delimiter)) {
    const candidate = join(dir, name);
    if (existsSync(candidate)) return candidate;
  }
  return null;
}

export interface RunResult {
  code: number;
  stdout: string;
  stderr: string;
}

export function run(cmd: string, args: string[], cwd?: string): Promise<RunResult> {
  return new Promise((resolve) => {
    execFile(cmd, args, { cwd, env: shellEnv(), maxBuffer: 50 * 1024 * 1024 }, (error, stdout, stderr) => {
      const code = error ? (typeof (error as NodeJS.ErrnoException & { code?: unknown }).code === "number" ? Number((error as { code: number }).code) : 1) : 0;
      resolve({ code, stdout: String(stdout), stderr: String(stderr) });
    });
  });
}

export async function git(root: string, args: string[]): Promise<string | null> {
  const result = await run("git", args, root);
  return result.code === 0 ? result.stdout.trim() : null;
}
