import { dirname, join, relative } from "node:path";
import * as vscode from "vscode";
// @ts-expect-error plain JS module
import { resolveOpen } from "../lib/model.mjs";
// @ts-expect-error plain JS module
import { staleReasons } from "../lib/staleness.mjs";
import { firstRunChecks } from "./checks";
import { ContextWriter, ensureCursorRule } from "./context";
import { LoadedMap, loadMap } from "./map";
import { FromPanel, MapPanel } from "./panel";
import { Runner } from "./runner";
import { git } from "./shell";
import { FileEntry, FilesTree } from "./tree";

const EMPTY_SCHEME = "pr-map-empty";

// Cursor's Git extension API. Reading `exports` before Git has started throws, so this starts it first.
// Without Git, PR Map still shows the map; it only loses diffs and the "branch moved" check.
async function gitApi(): Promise<any | null> {
  try {
    const git = vscode.extensions.getExtension("vscode.git");
    if (!git) return null;
    const exports = git.isActive ? git.exports : await git.activate();
    return exports?.getAPI?.(1) ?? null;
  } catch {
    return null;
  }
}

class Controller {
  private root: string | null = null;
  private map: LoadedMap | null = null;
  private saves: { path: string; at: number }[] = [];
  private head: string | null = null;
  // Tabs PR Map opened, so moving to the next file can close the one it opened before.
  private openedByUs = new Set<string>();
  readonly panel: MapPanel;
  readonly tree = new FilesTree();
  readonly runner: Runner;
  readonly chatContext = new ContextWriter(() => ({ root: this.root, map: this.map, stale: this.staleNow() }));

  constructor(private readonly context: vscode.ExtensionContext) {
    this.panel = new MapPanel(context.extensionUri, (m) => this.onPanel(m));
    this.runner = new Runner((progress) => this.panel.post({ type: "progress", progress }));
  }

  // The repo holding the file you're looking at, or the only folder open. With several and no file, ask.
  // Asked from the file's own folder, so a window on ~/Kikoff still finds the oasis repo inside it.
  async pickRoot(): Promise<string | null> {
    const folders = vscode.workspace.workspaceFolders ?? [];
    if (folders.length === 0) return null;
    const active = vscode.window.activeTextEditor?.document.uri;
    if (active?.scheme === "file") {
      const fromFile = await git(dirname(active.fsPath), ["rev-parse", "--show-toplevel"]);
      if (fromFile) return fromFile;
    }
    let folder = active ? vscode.workspace.getWorkspaceFolder(active) : undefined;
    if (!folder && folders.length === 1) folder = folders[0];
    if (!folder) {
      const picked = await vscode.window.showWorkspaceFolderPick({ placeHolder: "Which repo should PR Map show?" });
      if (!picked) return null;
      folder = picked;
    }
    return git(folder.uri.fsPath, ["rev-parse", "--show-toplevel"]);
  }

  async reload() {
    const root = this.root ?? (await this.pickRoot());
    if (!root) {
      this.panel.post({ type: "empty", reason: "Open the repo you want to map." });
      await this.tree.show(null);
      return;
    }
    this.root = root;
    const result = await loadMap(root);
    if ("problem" in result) {
      this.map = null;
      const checks = result.empty ? await firstRunChecks(root) : undefined;
      this.panel.post({ type: "empty", reason: result.problem, checks });
      await this.tree.show(null);
      this.chatContext.writeNow();
      return;
    }
    this.map = result.map;
    this.head = result.map.head;
    this.saves = [];
    this.panel.post({ type: "model", model: { ...result.map.model, stale: this.staleNow() } });
    this.postActiveFile(vscode.window.activeTextEditor);
    await ensureCursorRule(root).catch((error) => this.runner.log.appendLine(`Writing the Cursor rule failed: ${error}`));
    this.chatContext.fromEditor(vscode.window.activeTextEditor);
    this.chatContext.writeNow();
    await this.tree.show(result.map);
  }

  private covered(): Set<string> {
    const files = this.map?.sidecar.files?.map((f) => f.path) ?? Object.values(this.map?.sidecar.targets ?? {}).map((t) => t.path);
    return new Set(files);
  }

  private staleNow(): string[] {
    if (!this.map) return [];
    return staleReasons({ mappedHead: this.map.sidecar.mapped?.head, head: this.head, mappedAt: this.map.sidecar.mapped?.at, saves: this.saves, covered: this.covered() });
  }

  async refreshStale() {
    if (!this.map || !this.root) return;
    this.head = await git(this.root, ["rev-parse", "HEAD"]);
    this.panel.post({ type: "stale", reasons: this.staleNow() });
    this.chatContext.soon();
  }

  // Tells the panel which repo file the editor shows, so "This file" can follow you. In a diff, that's
  // the file-on-disk side. Display only: clicks never use this path.
  postActiveFile(editor: vscode.TextEditor | undefined) {
    if (!this.root || !editor || editor.document.uri.scheme !== "file") return;
    const path = relative(this.root, editor.document.uri.fsPath);
    if (path.startsWith("..")) return;
    this.panel.post({ type: "activeFile", path });
  }

  onSaved(doc: vscode.TextDocument) {
    if (!this.root || doc.uri.scheme !== "file") return;
    const path = relative(this.root, doc.uri.fsPath);
    if (path.startsWith("..")) return;
    this.saves.push({ path, at: Date.now() });
    this.refreshStale();
  }

  private async onPanel(message: FromPanel) {
    if (message.type === "tab") {
      if (message.flow) this.chatContext.setFlow(message.flow);
    } else if (message.type === "open") {
      if (!this.map) return;
      const target = resolveOpen(this.map.sidecar, message);
      if (target) await this.openFile(target.path, target.line);
    } else if (message.type === "mapThisPr") {
      await this.mapThisPr();
    } else if (message.type === "cancel") {
      this.runner.cancel();
    } else if (message.type === "showLog") {
      this.runner.log.show();
    }
  }

  async mapThisPr() {
    const root = this.root ?? (await this.pickRoot());
    if (!root) return;
    this.root = root;
    if (await this.runner.mapThisPr(root)) await this.reload();
  }

  // Opens the file in the editor you were in, replacing the tab PR Map opened last if it's unchanged.
  async openFile(path: string, line: number) {
    const uri = vscode.Uri.file(join(this.map!.root, path));
    const group = vscode.window.tabGroups.activeTabGroup;
    const previous = group.activeTab;
    const position = new vscode.Position(Math.max(0, line - 1), 0);
    try {
      await vscode.window.showTextDocument(uri, {
        viewColumn: group.viewColumn,
        preview: true,
        preserveFocus: false,
        selection: new vscode.Range(position, position),
      });
    } catch (error) {
      vscode.window.showWarningMessage(`Couldn't open ${path}: ${(error as Error).message}`);
      return;
    }
    const prevUri = previous?.input instanceof vscode.TabInputText ? previous.input.uri.toString() : null;
    if (previous && prevUri && prevUri !== uri.toString() && this.openedByUs.has(prevUri) && !previous.isDirty) {
      await vscode.window.tabGroups.close(previous, true);
    }
    this.openedByUs.add(uri.toString());
  }

  // The file's diff against the PR's base: left is the base version from git, right is the file on disk.
  async openDiff(file: FileEntry) {
    if (!this.map) return;
    const { root, mergeBase } = this.map;
    const api = await gitApi();
    if (!api || !mergeBase) {
      vscode.window.showWarningMessage("PR Map needs Cursor's Git extension and the PR's base commit to show a diff. Opening the file instead.");
      return this.openFile(file.path, 1);
    }
    const onDisk = vscode.Uri.file(join(root, file.path));
    const base = (path: string) => api.toGitUri(vscode.Uri.file(join(root, path)), mergeBase);
    const title = `${file.path.split("/").pop()} (${this.map.sidecar.mapped?.pr ? `PR ${this.map.sidecar.mapped.pr}` : "this branch"})`;
    if (file.status === "deleted") {
      return vscode.commands.executeCommand("vscode.open", base(file.path), { preview: true }, `${title}: deleted`);
    }
    const left = file.status === "added" ? vscode.Uri.from({ scheme: EMPTY_SCHEME, path: `/${file.path}` }) : base(file.oldPath ?? file.path);
    return vscode.commands.executeCommand("vscode.diff", left, onDisk, title, { preview: true });
  }

  async watch() {
    const subs = this.context.subscriptions;
    subs.push(vscode.workspace.onDidSaveTextDocument((doc) => this.onSaved(doc)));
    subs.push(vscode.window.onDidChangeActiveTextEditor((editor) => {
      this.postActiveFile(editor);
      this.chatContext.fromEditor(editor);
    }));
    subs.push(vscode.window.onDidChangeTextEditorSelection((e) => this.chatContext.fromEditor(e.textEditor)));
    for (const folder of vscode.workspace.workspaceFolders ?? []) {
      const current = vscode.workspace.createFileSystemWatcher(new vscode.RelativePattern(folder, ".pr-lens/current.json"));
      current.onDidCreate(() => this.reload());
      current.onDidChange(() => this.reload());
      subs.push(current);
    }
    // The Git extension's state changes when HEAD or the branch moves, including a commit.
    const api = await gitApi();
    const hook = (repo: any) => subs.push(repo.state.onDidChange(() => this.refreshStale()));
    api?.repositories?.forEach(hook);
    if (api?.onDidOpenRepository) subs.push(api.onDidOpenRepository(hook));
  }
}

export async function activate(context: vscode.ExtensionContext) {
  const controller = new Controller(context);
  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider("prMap.panel", controller.panel, { webviewOptions: { retainContextWhenHidden: true } }),
    vscode.window.registerTreeDataProvider("prMap.files", controller.tree),
    vscode.workspace.registerTextDocumentContentProvider(EMPTY_SCHEME, { provideTextDocumentContent: () => "" }),
    vscode.commands.registerCommand("prMap.mapThisPr", () => controller.mapThisPr()),
    vscode.commands.registerCommand("prMap.reload", () => controller.reload()),
    vscode.commands.registerCommand("prMap.fit", () => controller.panel.post({ type: "fit" })),
    vscode.commands.registerCommand("prMap.showLog", () => controller.runner.log.show()),
    vscode.commands.registerCommand("prMap.openDiff", (file: FileEntry) => controller.openDiff(file)),
    controller.runner.log,
  );
  // The panel and sidebar are registered above, so nothing below can leave them blank.
  try {
    await controller.watch();
  } catch (error) {
    controller.runner.log.appendLine(`Watching for changes failed: ${(error as Error).stack ?? error}`);
  }
  try {
    await controller.reload();
  } catch (error) {
    controller.runner.log.appendLine(`Loading the map failed: ${(error as Error).stack ?? error}`);
    controller.panel.post({ type: "empty", reason: `PR Map couldn't load the map: ${(error as Error).message}. Run "PR Map: Show log" for details.` });
  }
}

export function deactivate() {}
