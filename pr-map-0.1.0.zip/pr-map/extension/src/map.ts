import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
// @ts-expect-error plain JS module, shared with the browser page
import { loadDrawing } from "../../build_page.mjs";
// @ts-expect-error plain JS module
import { buildModel } from "../lib/model.mjs";
import { git } from "./shell";

const MAX_SVG_BYTES = 5 * 1024 * 1024;

export interface Sidecar {
  root?: string;
  mapped?: { head?: string; base?: string; mergeBase?: string; at?: string; branch?: string; pr?: number };
  targets?: Record<string, { path: string; line?: number; deleted?: boolean }>;
  steps?: { walkthroughStep: string; number: number; node: string; line?: number }[];
  flows?: {
    id: string;
    title: string;
    view: string;
    trigger?: { kind?: string; name?: string; path?: string; line?: number; node?: string };
    summary?: string;
    files?: { path: string; line?: number; node?: string; changed?: string }[];
  }[];
  files?: { path: string; oldPath?: string; status?: string; step?: number; line?: number; group?: string; does?: string; changed?: string }[];
  fileTable?: { step?: number; path: string; line?: number; role?: string; deleted?: boolean }[];
  folded?: { label: string; paths: string[] }[];
}

export interface LoadedMap {
  root: string;
  drawingDir: string;
  sidecar: Sidecar;
  graph: { title: string; walkthrough?: { steps: { id: string; heading: string }[] } };
  model: any;
  head: string | null;
  branch: string | null;
  mergeBase: string | null;
}

export type LoadResult = { map: LoadedMap } | { problem: string; empty?: boolean };

const readJson = (p: string) => JSON.parse(readFileSync(p, "utf8"));

// Older runs wrote .pr-lens/pr-map.json and rendered into .pr-lens/<title>/. The drawing whose graph has
// the same title, with the newest manifest, is the one that sidecar belongs to.
function legacyDrawing(lens: string): string | null {
  const graphPath = join(lens, "graph.json");
  if (!existsSync(graphPath)) return null;
  const title = readJson(graphPath).title;
  const candidates = readdirSync(lens, { withFileTypes: true })
    .filter((d) => d.isDirectory() && d.name !== "maps")
    .map((d) => join(lens, d.name))
    .filter((dir) => existsSync(join(dir, "manifest.json")) && existsSync(join(dir, "drawn.graph.json")))
    .filter((dir) => readJson(join(dir, "drawn.graph.json")).title === title)
    .sort((a, b) => statSync(join(b, "manifest.json")).mtimeMs - statSync(join(a, "manifest.json")).mtimeMs);
  return candidates[0] ?? null;
}

export async function loadMap(root: string): Promise<LoadResult> {
  const lens = join(root, ".pr-lens");
  const currentPath = join(lens, "current.json");
  let drawingDir: string | null = null;
  let sidecarPath: string | null = null;
  if (existsSync(currentPath)) {
    drawingDir = join(lens, readJson(currentPath).drawing);
    sidecarPath = join(drawingDir, "pr-map.json");
  } else if (existsSync(join(lens, "pr-map.json"))) {
    drawingDir = legacyDrawing(lens);
    sidecarPath = join(lens, "pr-map.json");
  }
  if (!drawingDir || !sidecarPath || !existsSync(sidecarPath)) {
    return { problem: "There's no map for this repo yet.", empty: true };
  }

  let drawing: { graph: any; svg: string; svgs: Record<string, string> };
  try {
    drawing = loadDrawing(drawingDir);
  } catch (error) {
    return { problem: `The map's drawing can't be read: ${(error as Error).message}` };
  }
  if (Buffer.byteLength(drawing.svg) > MAX_SVG_BYTES) {
    return { problem: "This map's diagram is over 5 MB, too big to show in the panel. Open the page in a browser instead." };
  }

  const sidecar: Sidecar = readJson(sidecarPath);
  const [head, branch] = await Promise.all([git(root, ["rev-parse", "HEAD"]), git(root, ["rev-parse", "--abbrev-ref", "HEAD"])]);
  const base = sidecar.mapped?.base ?? (await git(root, ["symbolic-ref", "--short", "refs/remotes/origin/HEAD"]));
  const mergeBase = sidecar.mapped?.mergeBase ?? (base ? await git(root, ["merge-base", base, "HEAD"]) : null);

  const model = buildModel({ graph: drawing.graph, sidecar, svg: drawing.svg, svgs: drawing.svgs, head, root, branch });
  if (model.broken) return { problem: model.broken.join(" ") };
  return { map: { root, drawingDir, sidecar, graph: drawing.graph, model, head, branch, mergeBase } };
}
