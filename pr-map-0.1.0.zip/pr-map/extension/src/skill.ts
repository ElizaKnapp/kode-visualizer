import { existsSync, realpathSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

// The skill this extension shows maps for. It finds the skill the same way Claude Code does from a repo:
// the repo's own .claude/skills/pr-map, then the user's ~/.claude/skills/pr-map.
export function skillDirFor(root: string): string | null {
  for (const dir of [join(root, ".claude/skills/pr-map"), join(homedir(), ".claude/skills/pr-map")]) {
    if (existsSync(join(dir, "SKILL.md"))) return realpathSync(dir);
  }
  return null;
}

// Every path the skill can be reached by from this repo. Claude names the skill by the path it found
// it at, often the repo's link, so a permission written for only the real folder wouldn't match.
export function skillPathsFor(root: string): string[] {
  const real = skillDirFor(root);
  if (!real) return [];
  const paths = [real];
  for (const dir of [join(root, ".claude/skills/pr-map"), join(homedir(), ".claude/skills/pr-map")]) {
    if (existsSync(join(dir, "SKILL.md")) && !paths.includes(dir)) paths.push(dir);
  }
  return paths;
}

export const preflightScript = (skill: string) => join(skill, "bin/preflight.mjs");
export const renderScript = (skill: string) => join(skill, "bin/render.mjs");
export const prLensBin = (skill: string) => join(skill, "node_modules/.bin/pr-lens");
