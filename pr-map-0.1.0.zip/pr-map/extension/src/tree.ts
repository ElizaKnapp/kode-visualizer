import { basename, dirname, join } from "node:path";
import * as vscode from "vscode";
// @ts-expect-error plain JS module
import { groupFiles, parseNameStatus } from "../lib/files.mjs";
import type { LoadedMap } from "./map";
import { git } from "./shell";

export interface FileEntry {
  path: string;
  oldPath?: string;
  status?: string;
  does?: string;
  changed?: string;
  step?: number;
  number?: number;
}

interface Group {
  label: string;
  collapsed: boolean;
  files: FileEntry[];
}

type Node = { kind: "group"; group: Group } | { kind: "file"; file: FileEntry };

// git's own list of what changed, so a file the map forgot still shows up.
export async function changedFiles(root: string, mergeBase: string | null): Promise<FileEntry[] | null> {
  if (!mergeBase) return null;
  const [tracked, untracked] = await Promise.all([
    git(root, ["diff", "--find-renames", "--name-status", mergeBase]),
    git(root, ["ls-files", "--others", "--exclude-standard"]),
  ]);
  if (tracked === null) return null;
  const added = (untracked ?? "").split("\n").filter(Boolean).map((path) => ({ status: "added", path }));
  return [...parseNameStatus(tracked), ...added];
}

export class FilesTree implements vscode.TreeDataProvider<Node> {
  private groups: Group[] = [];
  private map: LoadedMap | null = null;
  private readonly changed = new vscode.EventEmitter<void>();
  readonly onDidChangeTreeData = this.changed.event;

  async show(map: LoadedMap | null) {
    this.map = map;
    if (!map) {
      this.groups = [];
    } else {
      const steps = map.model.steps ?? [];
      const headings = Object.fromEntries(steps.map((s: any) => [s.number, s.heading]));
      const files = map.sidecar.files ?? legacyFiles(map);
      this.groups = groupFiles({ files, flows: map.sidecar.flows ?? [], steps, headings }, await changedFiles(map.root, map.mergeBase));
    }
    this.changed.fire();
  }

  getChildren(node?: Node): Node[] {
    if (!node) return this.groups.map((group) => ({ kind: "group", group }));
    return node.kind === "group" ? node.group.files.map((file) => ({ kind: "file", file })) : [];
  }

  getTreeItem(node: Node): vscode.TreeItem {
    if (node.kind === "group") {
      const item = new vscode.TreeItem(
        node.group.label,
        node.group.collapsed ? vscode.TreeItemCollapsibleState.Collapsed : vscode.TreeItemCollapsibleState.Expanded,
      );
      item.description = `${node.group.files.length}`;
      return item;
    }
    const { file } = node;
    const name = file.number ? `${file.number}. ${basename(file.path)}` : basename(file.path);
    const item = new vscode.TreeItem(name, vscode.TreeItemCollapsibleState.None);
    item.description = file.does ?? dirname(file.path);
    item.resourceUri = vscode.Uri.file(join(this.map!.root, file.path));
    const tip = new vscode.MarkdownString();
    tip.appendMarkdown(`**${file.path}** · ${file.status ?? "changed"}\n\n`);
    if (file.oldPath) tip.appendMarkdown(`Renamed from \`${file.oldPath}\`\n\n`);
    if (file.does) tip.appendMarkdown(`**What it does:** ${file.does}\n\n`);
    if (file.changed) tip.appendMarkdown(`**What this PR changes here:** ${file.changed}\n\n`);
    tip.appendMarkdown("_Click to open the diff._");
    item.tooltip = tip;
    item.iconPath = new vscode.ThemeIcon(file.status === "deleted" ? "diff-removed" : file.status === "added" ? "diff-added" : "diff-modified");
    item.contextValue = "prMapFile";
    item.command = { command: "prMap.openDiff", title: "Open diff", arguments: [file] };
    return item;
  }
}

// Sidecars from before `files` existed: their table and folded lists, read the same way.
function legacyFiles(map: LoadedMap): FileEntry[] {
  const rows = (map.sidecar.fileTable ?? []).map((r) => ({ path: r.path, step: r.step ?? undefined, does: r.role, status: r.deleted ? "deleted" : undefined }));
  const folded = (map.sidecar.folded ?? []).flatMap((g) => g.paths.map((path) => ({ path, group: g.label.startsWith("Spec") ? "Specs" : g.label.startsWith("Doc") ? "Docs" : "Other" })));
  return [...rows, ...folded];
}
