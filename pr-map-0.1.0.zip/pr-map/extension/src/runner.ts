import { ChildProcess, spawn } from "node:child_process";
import * as vscode from "vscode";
import { preflightScript, prLensBin, renderScript, skillDirFor, skillPathsFor } from "./skill";
import { run, shellEnv, which } from "./shell";

export interface Progress {
  running: boolean;
  lines: string[];
  outcome?: "done" | "failed" | "cancelled";
  message?: string;
}

// What the headless run may do: read anything, run read-only git commands and the pinned PR Lens
// validate, and write only inside .pr-lens/. `dontAsk` refuses everything else without asking, and
// it overrides any bypass mode in the user's own settings.
export function allowedTools(skillPaths: string[]): string[] {
  const readOnlyGit = ["diff", "ls-files", "status", "merge-base", "rev-parse", "show", "log", "symbolic-ref", "rev-list"];
  return [
    "Read", "Grep", "Glob", "Skill",
    "Write(.pr-lens/**)", "Edit(.pr-lens/**)",
    ...readOnlyGit.map((cmd) => `Bash(git ${cmd}:*)`),
    ...skillPaths.flatMap((skill) => [`Bash(node ${preflightScript(skill)}:*)`, `Bash(${prLensBin(skill)} validate:*)`]),
  ];
}

const describeTool = (name: string, input: any): string => {
  if (name === "Read") return `Reading ${String(input?.file_path ?? "").split("/").slice(-2).join("/")}`;
  if (name === "Write" || name === "Edit") return `Writing ${String(input?.file_path ?? "").split("/").pop()}`;
  if (name === "Bash") return `Running ${String(input?.command ?? "").split(" ").slice(0, 3).join(" ")}`;
  if (name === "Grep" || name === "Glob") return `Searching for ${String(input?.pattern ?? "")}`;
  return name;
};

export class Runner {
  private child: ChildProcess | null = null;
  private cancelled = false;
  readonly log = vscode.window.createOutputChannel("PR Map");

  constructor(private readonly onProgress: (p: Progress) => void) {}

  get running() {
    return this.child !== null;
  }

  cancel() {
    if (!this.child?.pid) return;
    this.cancelled = true;
    // The run was started as its own process group, so this stops Claude and everything it started.
    try {
      process.kill(-this.child.pid, "SIGTERM");
    } catch {
      this.child.kill("SIGTERM");
    }
  }

  async mapThisPr(root: string): Promise<boolean> {
    if (this.child) {
      vscode.window.showInformationMessage("A map is already being made for this repo.");
      return false;
    }
    const skill = skillDirFor(root);
    const node = which("node");
    const claude = which("claude");
    if (!skill || !node || !claude) {
      vscode.window.showErrorMessage("PR Map can't run yet. Open the PR Map panel to see what's missing.");
      return false;
    }

    const answer = await this.preflight(node, skill, root);
    if (!answer) return false;

    this.cancelled = false;
    const lines: string[] = [];
    const report = (line: string) => {
      lines.push(line);
      this.onProgress({ running: true, lines: lines.slice(-6) });
    };
    report(answer.pr ? `Mapping PR ${answer.pr} on ${answer.branch}…` : `Mapping ${answer.branch}…`);
    this.log.clear();
    this.log.appendLine(`$ claude -p "/pr-map ${answer.pr ?? ""} --headless" (in ${root})`);

    const prompt = `/pr-map ${answer.pr ?? ""} --headless`.replace(/\s+/g, " ");
    const args = ["-p", prompt, "--verbose", "--output-format", "stream-json", "--permission-mode", "dontAsk", "--allowedTools", ...allowedTools(skillPathsFor(root))];
    const finalText = await new Promise<string | null>((resolve) => {
      const child = spawn(claude, args, { cwd: root, env: shellEnv(), detached: true, stdio: ["ignore", "pipe", "pipe"] });
      this.child = child;
      let buffer = "";
      let result: string | null = null;
      child.stdout!.on("data", (chunk) => {
        buffer += chunk;
        let newline: number;
        while ((newline = buffer.indexOf("\n")) >= 0) {
          const line = buffer.slice(0, newline);
          buffer = buffer.slice(newline + 1);
          this.log.appendLine(line);
          try {
            const event = JSON.parse(line);
            if (event.type === "assistant") {
              for (const part of event.message?.content ?? []) if (part.type === "tool_use") report(describeTool(part.name, part.input));
            } else if (event.type === "result") {
              result = String(event.result ?? "");
            }
          } catch {
            // Not every line is an event.
          }
        }
      });
      child.stderr!.on("data", (chunk) => this.log.append(String(chunk)));
      child.on("close", () => {
        this.child = null;
        resolve(result);
      });
      child.on("error", (error) => {
        this.log.appendLine(String(error));
        this.child = null;
        resolve(null);
      });
    });

    if (this.cancelled) {
      this.onProgress({ running: false, lines, outcome: "cancelled", message: "Cancelled. The last map is still shown." });
      return false;
    }
    if (!finalText || !/MAP_READY/.test(finalText)) {
      const why = finalText?.match(/MAP_FAILED:\s*(.+)/)?.[1] ?? finalText?.trim().split("\n").pop() ?? "Claude stopped without a result.";
      this.onProgress({ running: false, lines, outcome: "failed", message: `No new map: ${why}` });
      return false;
    }

    report("Drawing the diagram…");
    const rendered = await run(node, [renderScript(skill), "--root", root], root);
    this.log.appendLine(rendered.stdout + rendered.stderr);
    if (rendered.code !== 0) {
      this.onProgress({ running: false, lines, outcome: "failed", message: `The map didn't render: ${rendered.stderr.trim().split("\n")[0]}` });
      return false;
    }
    this.onProgress({ running: false, lines, outcome: "done", message: "New map ready." });
    return true;
  }

  // Runs the branch check and asks its question in a dialog. Returns the go-ahead, or null to stop.
  private async preflight(node: string, skill: string, root: string, yes = false): Promise<any | null> {
    const result = await run(node, [preflightScript(skill), "--root", root, ...(yes ? ["--yes"] : [])], root);
    let answer: any;
    try {
      answer = JSON.parse(result.stdout);
    } catch {
      vscode.window.showErrorMessage(`PR Map's branch check failed: ${result.stderr.trim()}`);
      return null;
    }
    if (answer.ok) return answer;
    const message = String(answer.message).replace(/`/g, "");
    if (answer.confirmable) {
      const choice = await vscode.window.showWarningMessage(message, { modal: true }, "Map anyway");
      return choice === "Map anyway" ? this.preflight(node, skill, root, true) : null;
    }
    vscode.window.showWarningMessage(message, { modal: true });
    return null;
  }
}
