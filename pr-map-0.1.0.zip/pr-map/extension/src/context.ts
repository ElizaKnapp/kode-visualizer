import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync, appendFileSync } from "node:fs";
import { isAbsolute, join, relative } from "node:path";
import * as vscode from "vscode";
// @ts-expect-error plain JS module
import { buildContext, CURSOR_RULE, versionLabel } from "../lib/context.mjs";
import type { LoadedMap } from "./map";
import { git } from "./shell";

const RULE_PATH = ".cursor/rules/pr-map.mdc";
const WAIT_MS = 300;

export interface Where {
  flow: string | null;
  file: string | null;
  selection: { path: string; startLine: number; endLine: number; text: string; version: string } | null;
}

// Keeps .pr-lens/context.md in step with what you're looking at, for Cursor's chat to read. It writes a
// moment after you stop moving, so arrowing through a file doesn't rewrite it on every keypress.
export class ContextWriter {
  private where: Where = { flow: null, file: null, selection: null };
  private timer: NodeJS.Timeout | null = null;

  constructor(private readonly current: () => { root: string | null; map: LoadedMap | null; stale: string[] }) {}

  setFlow(flow: string) {
    if (flow === this.where.flow) return;
    this.where.flow = flow;
    this.soon();
  }

  fromEditor(editor: vscode.TextEditor | undefined) {
    const { root, map } = this.current();
    if (!root || !editor) return;
    const located = locate(editor.document.uri, root);
    if (!located) return;
    this.where.file = located.path;
    const sel = editor.selection;
    if (sel.isEmpty) {
      this.where.selection = null;
    } else {
      // A selection that ends at the start of a line doesn't include that line.
      const endLine = sel.end.character === 0 && sel.end.line > sel.start.line ? sel.end.line : sel.end.line + 1;
      this.where.selection = {
        path: located.path,
        startLine: sel.start.line + 1,
        endLine,
        text: editor.document.getText(sel),
        version: versionLabel(located.ref, map?.mergeBase ?? null),
      };
    }
    this.soon();
  }

  soon() {
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => this.writeNow(), WAIT_MS);
  }

  writeNow() {
    this.timer = null;
    const { root, map, stale } = this.current();
    if (!root) return;
    const lens = join(root, ".pr-lens");
    // A repo that has never been mapped doesn't get a .pr-lens folder from this.
    if (!existsSync(lens)) return;
    const text = buildContext(map ? { model: map.model, sidecar: map.sidecar, mergeBase: map.mergeBase } : null, this.where, stale);
    const path = join(lens, "context.md");
    writeFileSync(`${path}.tmp`, text);
    renameSync(`${path}.tmp`, path);
  }
}

// Which repo file an editor shows, and for the left side of a diff, which version.
function locate(uri: vscode.Uri, root: string): { path: string; ref?: string } | null {
  let fsPath: string;
  let ref: string | undefined;
  if (uri.scheme === "file") {
    fsPath = uri.fsPath;
  } else if (uri.scheme === "git") {
    try {
      const query = JSON.parse(uri.query);
      fsPath = query.path;
      ref = query.ref;
    } catch {
      return null;
    }
  } else {
    return null;
  }
  const path = relative(root, fsPath);
  return path && !path.startsWith("..") && !isAbsolute(path) ? { path, ref } : null;
}

// Writes the Cursor rule that points the chat at context.md, once, and keeps it out of git through
// .git/info/exclude, the same way .pr-lens/ is kept out.
export async function ensureCursorRule(root: string) {
  const rule = join(root, RULE_PATH);
  if (!existsSync(rule) || readFileSync(rule, "utf8") !== CURSOR_RULE) {
    mkdirSync(join(root, ".cursor/rules"), { recursive: true });
    writeFileSync(rule, CURSOR_RULE);
  }
  if ((await git(root, ["check-ignore", "-q", RULE_PATH])) === null) {
    const exclude = await git(root, ["rev-parse", "--git-path", "info/exclude"]);
    if (exclude) appendFileSync(isAbsolute(exclude) ? exclude : join(root, exclude), `\n${RULE_PATH}\n`);
  }
}
