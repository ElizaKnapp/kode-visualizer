// Bundles the extension host code and the panel's script. esbuild strips types without checking them.
import { build } from "esbuild";

await build({
  entryPoints: ["src/extension.ts"],
  bundle: true,
  platform: "node",
  format: "cjs",
  target: "node20",
  external: ["vscode"],
  outfile: "dist/extension.js",
  // build_page.mjs checks import.meta.url only to run as a script, and is a library here.
  logOverride: { "empty-import-meta": "silent" },
});
await build({
  entryPoints: ["media/panel.mjs"],
  bundle: true,
  platform: "browser",
  format: "iife",
  target: "es2022",
  outfile: "dist/panel.js",
});
