---
name: pr-map
description: "Turns a PR or the current branch into a map: a diagram in story order, what every changed file does, and a summary of each story file's diff. Shown in the PR Map panel in Cursor, or as a local web page. Use when asked to map, diagram or walk through a PR to understand it faster, or invoked as /pr-map [pr-number] [--root <path>] [--headless]. Local only; never posts to GitHub."
---

# pr-map

A map of one PR, in the order things happen. The Cursor extension shows it in a bottom panel and the
left sidebar. The same map is also a local web page. PR Lens (pinned) draws the diagram. Everything
else is ours.

`SKILL_DIR` below is the folder this SKILL.md is in (Claude Code shows it as the skill's base directory).
Use its full path. Run every command from the
root of the repo being mapped.

**Your job is two files: `.pr-lens/graph.json` and `.pr-lens/pr-map.json`.** Scripts do the rest.
Never run `pr-lens canvas`, `analyze`, `auth` or `comment`. Those send code off the machine. Never
commit, stage, or change any file outside `.pr-lens/`.

## Headless mode

`--headless` means the Cursor extension started you with no one to answer questions. It has already run
the preflight check and asked any question itself. So with `--headless`:
- You may only read files, run read-only `git` commands, run preflight and `pr-lens validate`, and write
  inside `.pr-lens/`. Anything else is refused. Write each command plainly so it matches that list:
  - The full path, no `$VARS` and no quotes: `node /Users/…/pr-map/bin/preflight.mjs 6972 --yes`.
  - No pipes, `&&` or redirects: `git diff --stat 7da878f`, not `git diff | head`.
  - No `git -C`. You already run in the repo root.
  - Read files with the Read tool, not `cat`.
- Skip `bin/setup`. The extension already checked PR Lens is installed.
- Run preflight with `--yes` (step 1), and stop only if it still says `"ok": false`.
- Write the two files and validate them (steps 2 to 6).
- **Don't run `bin/render`, and don't open anything.** The extension renders when you finish.
- End with one line: `MAP_READY` when both files are written and valid, or `MAP_FAILED: <why>`.

## 1. Check you're looking at the right work

Do this before reading any code.

```bash
"$SKILL_DIR/bin/setup"                                     # installs the pinned PR Lens once
node "$SKILL_DIR/bin/preflight.mjs" [<pr-number>] [--root <path>] [--yes]
```

It prints JSON. With `"ok": true` it gives `root`, `branch`, `base`, `mergeBase`, `head` and `pr`. Use
them below.

With `"ok": false`, it gives a `message`. Ask the person that question, word for word, and wait.
- When `confirmable` is true and they say yes, run preflight again with `--yes`.
- When `confirmable` is false (wrong branch, old Node, no PR Lens), there's nothing to say yes to. Stop.

Never check out a branch yourself.

## 2. Read the change

```bash
git diff --find-renames --name-status "$MERGE_BASE"
git diff --find-renames "$MERGE_BASE"           # against the files on disk: staged + unstaged count
git ls-files --others --exclude-standard        # new files the diff above leaves out
```

Read the changed files themselves, not only the hunks. Line numbers must match the files on disk,
because that's what clicks open. Binary files get listed but get no line.

## 3. How the words are written

Every step heading, step body and file summary follows these rules (and `~/Kikoff/.claude/writing-style.md`,
if that file exists): a softened ASD-STE100 (the controlled English of aircraft maintenance manuals), about 80% of the way:
- One idea per sentence. Instructions up to 20 words, descriptions up to 25.
- Active voice. Name who does what: "The job locks the alert," not "The alert is locked."
- Common words. The same word for the same thing every time: "repayment" once means "repayment"
  everywhere, never "loan".
- No "-ing" words as nouns. No stacked nouns like "retry assignment store key".
- Code names go in backticks and count as one word.
- Name the step that moves money, touches PII, or reads a flag or experiment.

## 4. Write `.pr-lens/graph.json`

Follow `$SKILL_DIR/vendor/pr-lens-references.md` (the field-by-field reference for the pinned version)
and its example. Then these rules, which beat anything in the reference:

- **Architecture views only.** `"lenses": ["architecture"]`, no PR Lens `flows`.
- **Views: one "overview", then one per flow (step 5), all at the top level.**
  - `overview`: `scope: { "kind": "all" }`, `defaultOpen: true`. The browser page shows it; the panel
    shows only the flows.
  - One view per flow, id `flow-<flow id>`: `scope: { "kind": "selection", "nodes": [...], "edges": [...] }`
    with the flow's trigger node, its file nodes, and the unchanged neighbours they call. Small: about 3
    to 7 boxes. This is that flow's tab.
- **Story order.** The walkthrough follows one request through the code:
  1. The entry point: the webhook, job, endpoint, or the hook into an existing flow where new code first
     runs.
  2. Then each call it makes, in the order it makes them.
  3. Supporting pieces (migrations, constants, config, event contracts) last.
  - 2 to 12 steps. Each step focuses the one node it's about.
  - Two unrelated starting points → two stories, one after the other. Say so in the step text.
- **Nodes.** One per class or file that matters. Every node with code has
  `files: [{ "path", "startLine" }]`, with `startLine` on the class or method that matters. Keep the
  unchanged neighbours the change talks to, marked `unchanged`.
- **Labels are unique and short.** Boxes are found by their title, so two boxes must never share one,
  and a label longer than the box gets cut off. About 30 characters. Use plain words or the class name
  without namespaces; the full class name goes in `subtitle`.
- **No real data.** Placeholder values only.

## 5. Write `.pr-lens/pr-map.json`

Our extras. They say where every click goes and what every file does.

```json
{
  "version": 2,
  "root": "<root>",
  "mapped": { "head": "<head>", "base": "<base>", "mergeBase": "<mergeBase>", "at": "<ISO time>", "branch": "<branch>", "pr": 6972 },
  "targets": {
    "<node-id>": { "path": "app/jobs/payments/process_mastercard_payment_alert_job.rb", "line": 11 },
    "<deleted-node-id>": { "path": "app/old_thing.rb", "deleted": true }
  },
  "steps": [ { "walkthroughStep": "<walkthrough step id>", "number": 1, "node": "<node-id>" } ],
  "files": [
    {
      "path": "app/activities/cash_advance/payment_activity.rb",
      "status": "modified",
      "step": 1,
      "line": 224,
      "group": "Story",
      "does": "Charges the card for a repayment and handles a decline.",
      "changed": "A decline now enrolls the repayment in the experiment. During a 24-hour hold, it skips smart-card charges."
    },
    { "path": "spec/activities/payments/assign_mastercard_pop_retry_activity_spec.rb", "status": "added", "group": "Specs", "does": "Tests arm assignment." }
  ],
  "edges": { "<edge-id>": { "source": "inferred" } }
}
```

- `targets`: every node with code. Same path and line as its `files` entry in `graph.json`.
- `steps`: one per walkthrough step, numbered 1 up, in story order. Add `"line"` to a step when it's
  about a different spot in its node's file, like a second step on the same class.
- `files`: **every changed file, exactly once**, including new untracked ones. Check it against step 2's
  lists before you finish.
  - `status`: `added`, `modified`, `deleted` or `renamed`. A renamed file also gets `oldPath`.
  - **Story files** (the ones a step is about) get `step`, `line`, `group: "Story"`, a one-line `does`
    (what the file is for), and `changed`: two or three sentences on what this diff changes in it.
  - **Every other file** gets only a one-line `does`, and `group`: `Specs`, `Docs` or `Other`.
- `edges[].source`: always `"inferred"` for now.
- `flows`: see below.

### Flows

A flow is one path through the PR that one trigger starts. The reader reviews one flow at a time, so
each flow must make sense alone.

```json
"flows": [
  {
    "id": "retry",
    "title": "RETRY_NOW → retry charge",
    "view": "flow-retry",
    "trigger": { "kind": "webhook", "name": "POST /webhooks/mastercard-pop", "path": "app/controllers/webhooks/mastercard_pop_controller.rb", "line": 20, "node": "webhook" },
    "summary": "Mastercard posts RETRY_NOW. The job matches it to our decline, then checks the arm and books a balance refresh. The refresh charges the card if the balance covers it.",
    "files": [
      { "path": "app/jobs/payments/process_mastercard_payment_alert_job.rb", "line": 50, "node": "alert-job", "changed": "The job now schedules the retry inside the match lock. If scheduling raises, the match rolls back." }
    ]
  }
]
```

- **One flow per trigger.** A trigger is what starts the code from outside it: an API route
  (`kind: "api"`, name `POST /api/v1/...`), a webhook (`"webhook"`), a Sidekiq or scheduled job
  (`"job"` or `"schedule"`, name the class), or an event or a call from an existing flow (`"event"`,
  name what fires it, like "A card charge declines in `CashAdvance::PaymentActivity`").
- **The trigger is the outermost entry point, not the first changed file.** Walk back from the changed
  code until you leave the repo. A job enqueued by a webhook starts at the webhook route, not the job.
  The trigger's box goes in the flow's view even when its file is unchanged.
- **Find every trigger** that reaches new or changed code. Most PRs have 1 to 4 flows.
- **`title`**: what happens, in a few words: "Decline → enroll", "RETRY_NOW → retry charge".
- **`trigger.path` and `line`**: where the trigger is defined, so it can be opened. Leave them out when
  there's no single place.
- **`files`: 3 to 5 changed files, in the order the code runs them**, starting nearest the trigger. If
  the job calls match and then schedule, match comes first. Only files
  this PR changes, and never specs. If a flow needs more than 5, split it into two flows.
- **`summary`**: 2 or 3 sentences. Start at the trigger, then say how the files work together and what
  the flow does for the user or the money.
- **`files[].changed`**: what this PR changes in that file *for this flow*, in 1 to 3 sentences. A file in
  two flows gets a different summary in each, about its part in that flow.
- **Show where money moves.** If the flow ends in a charge, payout or transfer, put that box in the view
  (unchanged is fine) and say so in `summary`.
- Every story step still points at a node. The steps tell the whole-PR story on the browser page.

## 6. Validate

```bash
"$SKILL_DIR/node_modules/.bin/pr-lens" validate .pr-lens/graph.json
```

Fix every failure and run it again. Stop after 5 tries and show the errors. Never delete an element just
to make a failure go away.

**With `--headless`, stop here** and print `MAP_READY`.

## 7. Render and open

```bash
node "$SKILL_DIR/bin/render.mjs" --open
```

It validates again, renders into a fresh folder under `.pr-lens/maps/`, builds the page, and only then
makes it the current map. If anything fails, the old map stays current.
- "Some boxes aren't clickable": fix the labels it names in `graph.json`, then run it again.
- "Refusing to build the page": the sidecar and the drawing disagree. Fix `pr-map.json`.

## 8. Hand it back

Say where the page is, how many steps the story has, and anything the map couldn't show. Point out the
step that moves money or reads a flag, if any. Say that arrows are the agent's reading of the code.
